const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const DRIVER_A_UID = "driver_a_123";
const DRIVER_B_UID = "driver_b_456";
const PASSENGER_UID = "passenger_789";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function validDriverProfilePayload(uid, overrides = {}) {
  const now = new Date(Date.now() - 2000);
  return {
    userId: uid,
    fullName: "Mateus Domingos",
    phone: "+244 923 456 789",
    vehicleModel: "Toyota Hiace",
    vehicleColor: "Azul e Branco",
    licensePlate: "LD-45-89-AB",
    maxSeats: 14,
    defaultRoute: "Benfica \u2192 Mutamba",
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

function validActiveTaxiPayload(uid, overrides = {}) {
  const now = new Date(Date.now() - 2000);
  return {
    driverId: uid,
    driverName: "Mateus Domingos",
    vehicleModel: "Toyota Hiace",
    vehicleColor: "Azul e Branco",
    licensePlate: "LD-45-89-AB",
    route: "Benfica \u2192 Mutamba",
    availableSeats: 3,
    maxSeats: 14,
    status: "ACTIVE",
    latitude: -8.839,
    longitude: 13.2894,
    bearing: 45.0,
    speedKmh: 38.5,
    accuracyMeters: 12.0,
    hasGpsFix: true,
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

function validTaxiStopPayload(uid, overrides = {}) {
  const now = new Date(Date.now() - 2000);
  return {
    createdBy: uid,
    name: "Paragem da Mutamba",
    routeHint: "Benfica \u2192 Mutamba",
    stopType: "TAXI_STOP",
    status: "ACTIVE",
    latitude: -8.8147,
    longitude: 13.2302,
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated users cannot read or write drivers, active_taxis, or taxi_stops", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();

  await assertFails(unauthDb.collection("drivers").doc(DRIVER_A_UID).get());
  await assertFails(
    unauthDb.collection("drivers").doc(DRIVER_A_UID).set(validDriverProfilePayload(DRIVER_A_UID))
  );
  await assertFails(
    unauthDb.collection("active_taxis").where("status", "==", "ACTIVE").get()
  );
  await assertFails(
    unauthDb.collection("active_taxis").doc(DRIVER_A_UID).set(validActiveTaxiPayload(DRIVER_A_UID))
  );
  await assertFails(
    unauthDb.collection("taxi_stops").where("status", "==", "ACTIVE").get()
  );
  await assertFails(
    unauthDb.collection("taxi_stops").doc("stop_1").set(validTaxiStopPayload(DRIVER_A_UID))
  );
});

test("Driver profile PII isolation: owner can CRUD, other users cannot read or write", async () => {
  const driverADb = testEnv.authenticatedContext(DRIVER_A_UID).firestore();
  const driverBDb = testEnv.authenticatedContext(DRIVER_B_UID).firestore();

  await assertSucceeds(
    driverADb.collection("drivers").doc(DRIVER_A_UID).set(validDriverProfilePayload(DRIVER_A_UID))
  );

  await assertSucceeds(
    driverADb.collection("drivers").doc(DRIVER_A_UID).update({
      defaultRoute: "Kilamba \u2192 Mutamba",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  await assertFails(driverBDb.collection("drivers").doc(DRIVER_A_UID).get());
  await assertFails(
    driverBDb.collection("drivers").doc(DRIVER_A_UID).update({
      phone: "+244 999 999 999",
      updatedAt: new Date(Date.now() - 500),
    })
  );
});

test("Active taxi lifecycle: create, GPS update, seat update, and end trip succeed for owner", async () => {
  const driverADb = testEnv.authenticatedContext(DRIVER_A_UID).firestore();

  await assertSucceeds(
    driverADb.collection("active_taxis").doc(DRIVER_A_UID).set(validActiveTaxiPayload(DRIVER_A_UID))
  );

  await assertSucceeds(
    driverADb.collection("active_taxis").doc(DRIVER_A_UID).update({
      latitude: -8.842,
      longitude: 13.291,
      bearing: 90.0,
      speedKmh: 42.0,
      accuracyMeters: 8.5,
      hasGpsFix: true,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  await assertSucceeds(
    driverADb.collection("active_taxis").doc(DRIVER_A_UID).update({
      availableSeats: 2,
      updatedAt: new Date(Date.now() - 900),
    })
  );

  await assertSucceeds(
    driverADb.collection("active_taxis").doc(DRIVER_A_UID).update({
      status: "INACTIVE",
      hasGpsFix: false,
      updatedAt: new Date(Date.now() - 700),
    })
  );
});

test("Taxi stops: authenticated user can register and list active stops, cannot modify another user's stop", async () => {
  const driverADb = testEnv.authenticatedContext(DRIVER_A_UID).firestore();
  const passengerDb = testEnv.authenticatedContext(PASSENGER_UID).firestore();

  await assertSucceeds(
    driverADb.collection("taxi_stops").doc("stop_mutamba").set(validTaxiStopPayload(DRIVER_A_UID))
  );

  const snap = await assertSucceeds(
    passengerDb.collection("taxi_stops").where("status", "==", "ACTIVE").get()
  );
  if (snap.size !== 1) {
    throw new Error(`Expected 1 taxi stop, got ${snap.size}`);
  }

  // Unfiltered query must fail
  await assertFails(passengerDb.collection("taxi_stops").get());

  // Non-creator cannot edit or delete
  await assertFails(
    passengerDb.collection("taxi_stops").doc("stop_mutamba").update({
      name: "Hijacked Stop",
      updatedAt: new Date(Date.now() - 500),
    })
  );
  await assertFails(passengerDb.collection("taxi_stops").doc("stop_mutamba").delete());
});
