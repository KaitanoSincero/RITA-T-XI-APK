package com.example

import android.location.Location
import com.example.data.LocationSource
import com.example.data.OsmPoiDataSource
import com.example.data.TaxiDataSource
import com.example.model.ActiveTaxi
import com.example.model.MapPoi
import com.example.model.PoiCategory
import com.example.model.TaxiStatus
import com.example.model.TaxiStop
import com.example.model.TaxiStopType
import com.example.ui.passenger.PassengerUiData
import com.example.ui.passenger.PassengerViewModel
import com.example.ui.state.UiState
import com.example.util.MapRadiusKm
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PassengerMapRobolectricTest {

    private val testDispatcher = StandardTestDispatcher()

    // Passenger GPS at Mutamba, Luanda
    private val passengerLat = -8.8147
    private val passengerLng = 13.2302

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    private fun makeLocation(lat: Double, lng: Double): Location = Location("gps").apply {
        latitude = lat
        longitude = lng
    }

    private fun taxi(
        id: String,
        route: String,
        lat: Double,
        lng: Double,
        seats: Long = 3L,
        hasFix: Boolean = true
    ) = ActiveTaxi(
        id = id,
        driverId = id,
        driverName = "Motorista $id",
        vehicleModel = "Toyota Hiace",
        vehicleColor = "Azul e Branco",
        licensePlate = "LD-00-$id",
        route = route,
        availableSeats = seats,
        maxSeats = 14L,
        status = TaxiStatus.ACTIVE.wireValue,
        latitude = lat,
        longitude = lng,
        hasGpsFix = hasFix
    )

    private class FakeTaxiDataSource : TaxiDataSource {
        val activeTaxisFlow = MutableStateFlow<List<ActiveTaxi>>(emptyList())
        val stopsFlow = MutableStateFlow<List<TaxiStop>>(emptyList())
        val createdStops = mutableListOf<TaxiStop>()

        override fun observeActiveTaxis(): Flow<List<ActiveTaxi>> = activeTaxisFlow
        override fun observeTaxiStops(): Flow<List<TaxiStop>> = stopsFlow
        override suspend fun createTaxiStop(
            name: String,
            routeHint: String,
            stopType: TaxiStopType,
            latitude: Double,
            longitude: Double
        ): Result<Unit> {
            val stop = TaxiStop(
                id = "stop_${createdStops.size + 1}",
                createdBy = "test_user",
                name = name,
                routeHint = routeHint,
                stopType = stopType.wireValue,
                status = TaxiStatus.ACTIVE.wireValue,
                latitude = latitude,
                longitude = longitude
            )
            createdStops.add(stop)
            stopsFlow.value = stopsFlow.value + stop
            return Result.success(Unit)
        }
    }

    private class FakeLocationSource(
        var permissionGranted: Boolean = true,
        var current: Location? = null
    ) : LocationSource {
        val updates = MutableSharedFlow<Location>(replay = 1)
        override fun hasLocationPermission(): Boolean = permissionGranted
        override suspend fun getCurrentLocation(): Location? = current
        override fun observeLocationUpdates(intervalMillis: Long): Flow<Location> = updates
    }

    private class FakeOsmPoiDataSource(private val allPois: List<MapPoi>) : OsmPoiDataSource {
        val requestedRadii = mutableListOf<Int>()
        override suspend fun fetchPoisWithinRadius(
            centerLat: Double,
            centerLng: Double,
            radiusKm: Int
        ): Result<List<MapPoi>> {
            requestedRadii.add(radiusKm)
            return Result.success(allPois)
        }
    }

    @Test
    fun `initial 5 km radius and dynamic expansion across 5, 10, 15, 20 km filter taxis and POIs accurately`() =
        runTest(testDispatcher) {
            val taxi3km = taxi("t3", "Benfica → Mutamba", -8.8380, 13.2520)       // ~3.5 km
            val taxi8km = taxi("t8", "Viana → Congolenses", -8.8850, 13.2080)     // ~8.2 km
            val taxi14km = taxi("t14", "Kilamba → Mutamba", -8.9280, 13.1850)     // ~13.5 km
            val taxi19km = taxi("t19", "Zango → Viana", -8.9020, 13.3740)         // ~18.5 km
            val taxi32km = taxi("t32", "Barra do Kwanza → Mutamba", -9.0500, 13.4500) // ~32 km

            val repo = FakeTaxiDataSource().apply {
                activeTaxisFlow.value = listOf(taxi3km, taxi8km, taxi14km, taxi19km, taxi32km)
                stopsFlow.value = listOf(
                    TaxiStop(id = "s1", name = "Paragem Mutamba", latitude = -8.8150, longitude = 13.2310),
                    TaxiStop(id = "s2", name = "Paragem Viana", latitude = -8.9020, longitude = 13.3740)
                )
            }
            val gps = FakeLocationSource(
                permissionGranted = true,
                current = makeLocation(passengerLat, passengerLng)
            )
            val osmPois = listOf(
                MapPoi("h1", "Hospital Central", PoiCategory.HOSPITAL, -8.8180, 13.2340),
                MapPoi("m1", "Mercado 12km", PoiCategory.MARKET, -8.9150, 13.1900)
            )
            val osmRepo = FakeOsmPoiDataSource(osmPois)

            val vm = PassengerViewModel(repo, gps, osmRepo)
            val collectJob = launch { vm.uiState.collect {} }
            advanceUntilIdle()

            // Initial default radius MUST be 5 KM centered on passenger GPS
            assertEquals(MapRadiusKm.KM_5, vm.filterState.value.selectedRadius)
            var data = (vm.uiState.value as UiState.Success<PassengerUiData>).data
            assertEquals(listOf("t3"), data.filteredTaxis.map { it.driverId })
            assertEquals(listOf("fb_s1"), data.firebaseStopsInRadius.map { it.id })
            assertTrue(data.visiblePois.any { it.id == "h1" })
            assertTrue(data.visiblePois.none { it.id == "m1" })

            // Expand to 10 KM
            vm.selectRadius(MapRadiusKm.KM_10)
            advanceUntilIdle()
            data = (vm.uiState.value as UiState.Success<PassengerUiData>).data
            assertEquals(setOf("t3", "t8"), data.filteredTaxis.map { it.driverId }.toSet())

            // Expand to 15 KM
            vm.selectRadius(MapRadiusKm.KM_15)
            advanceUntilIdle()
            data = (vm.uiState.value as UiState.Success<PassengerUiData>).data
            assertEquals(setOf("t3", "t8", "t14"), data.filteredTaxis.map { it.driverId }.toSet())
            assertTrue(data.visiblePois.any { it.id == "m1" })

            // Expand to max 20 KM (taxi32km stays excluded)
            vm.selectRadius(MapRadiusKm.KM_20)
            advanceUntilIdle()
            data = (vm.uiState.value as UiState.Success<PassengerUiData>).data
            assertEquals(setOf("t3", "t8", "t14", "t19"), data.filteredTaxis.map { it.driverId }.toSet())
            assertEquals(setOf("fb_s1", "fb_s2"), data.firebaseStopsInRadius.map { it.id }.toSet())

            // Shrink back to 5 KM and verify only 5 KM taxis remain
            vm.selectRadius(MapRadiusKm.KM_5)
            advanceUntilIdle()
            data = (vm.uiState.value as UiState.Success<PassengerUiData>).data
            assertEquals(listOf("t3"), data.filteredTaxis.map { it.driverId })

            collectJob.cancel()
        }

    @Test
    fun `firebase real-time update removes taxi from view when it drives outside selected radius`() =
        runTest(testDispatcher) {
            val initialTaxi = taxi("t1", "Benfica → Mutamba", -8.8200, 13.2350, seats = 4)
            val repo = FakeTaxiDataSource().apply {
                activeTaxisFlow.value = listOf(initialTaxi)
            }
            val gps = FakeLocationSource(
                permissionGranted = true,
                current = makeLocation(passengerLat, passengerLng)
            )
            val vm = PassengerViewModel(repo, gps, FakeOsmPoiDataSource(emptyList()))
            val collectJob = launch { vm.uiState.collect {} }
            advanceUntilIdle()

            vm.selectTaxi("t1")
            advanceUntilIdle()
            var data = (vm.uiState.value as UiState.Success<PassengerUiData>).data
            assertEquals(1, data.filteredTaxis.size)
            assertNotNull(data.selectedTaxi)

            // Taxi drives 8.2 km away (outside 5 km radius), Firebase pushes updated coordinates
            repo.activeTaxisFlow.value = listOf(
                initialTaxi.copy(latitude = -8.8850, longitude = 13.2080, availableSeats = 2)
            )
            advanceUntilIdle()

            data = (vm.uiState.value as UiState.Success<PassengerUiData>).data
            // Removed from passenger view without deleting from Firebase list
            assertTrue(data.filteredTaxis.isEmpty())
            assertNull(data.selectedTaxi)
            assertEquals(1, repo.activeTaxisFlow.value.size)

            // Refresh GPS does not reset selected radius
            vm.selectRadius(MapRadiusKm.KM_10)
            advanceUntilIdle()
            vm.refreshPassengerLocation()
            advanceUntilIdle()
            assertEquals(MapRadiusKm.KM_10, vm.filterState.value.selectedRadius)
            data = (vm.uiState.value as UiState.Success<PassengerUiData>).data
            assertEquals(1, data.filteredTaxis.size)
            assertEquals(2L, data.filteredTaxis.first().availableSeats)

            collectJob.cancel()
        }

    @Test
    fun `poi category toggles and route filters operate cleanly inside active radius`() =
        runTest(testDispatcher) {
            val repo = FakeTaxiDataSource().apply {
                activeTaxisFlow.value = listOf(
                    taxi("t1", "Benfica → Mutamba", -8.8200, 13.2350),
                    taxi("t2", "Kilamba → Mutamba", -8.8220, 13.2360)
                )
            }
            val gps = FakeLocationSource(
                permissionGranted = true,
                current = makeLocation(passengerLat, passengerLng)
            )
            val osmRepo = FakeOsmPoiDataSource(
                listOf(
                    MapPoi("h1", "Hospital Josina Machel", PoiCategory.HOSPITAL, -8.8170, 13.2330),
                    MapPoi("b1", "Banco BFA", PoiCategory.BANK, -8.8180, 13.2340)
                )
            )

            val vm = PassengerViewModel(repo, gps, osmRepo)
            val collectJob = launch { vm.uiState.collect {} }
            advanceUntilIdle()

            vm.selectRouteFilter("Benfica → Mutamba")
            vm.togglePoiCategory(PoiCategory.BANK)
            advanceUntilIdle()

            val data = (vm.uiState.value as UiState.Success<PassengerUiData>).data
            assertEquals(listOf("t1"), data.filteredTaxis.map { it.driverId })
            assertTrue(data.visiblePois.any { it.id == "h1" })
            assertTrue(data.visiblePois.none { it.id == "b1" })

            // Register a stop via repository and confirm it appears
            var saveOk = false
            vm.registerTaxiStop("Paragem Teste", "Benfica → Mutamba", TaxiStopType.TAXI_STOP, passengerLat, passengerLng) {
                saveOk = it.isSuccess
            }
            advanceUntilIdle()
            assertTrue(saveOk)
            val refreshed = (vm.uiState.value as UiState.Success<PassengerUiData>).data
            assertTrue(refreshed.firebaseStopsInRadius.any { it.name == "Paragem Teste" })

            collectJob.cancel()
        }
}
