package com.example

import com.example.data.OsmPoiRepository
import com.example.model.PoiCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class OsmPoiRepositoryTest {

    private val repo = OsmPoiRepository()
    private val centerLat = -8.8147
    private val centerLng = 13.2302

    @Test
    fun `buildOverpassQuery uses passenger GPS center and clamps max radius to 20 km`() {
        val query5km = repo.buildOverpassQuery(centerLat, centerLng, 5_000)
        assertTrue(query5km.contains("(around:5000,$centerLat,$centerLng)"))
        assertTrue(query5km.contains("\"highway\"=\"bus_stop\""))
        assertTrue(query5km.contains("hospital"))
        assertTrue(query5km.contains("school"))
        assertTrue(query5km.contains("marketplace"))
        assertTrue(query5km.contains("bank"))

        val clamped = repo.buildOverpassQuery(centerLat, centerLng, 50_000)
        assertTrue(clamped.contains("(around:20000,$centerLat,$centerLng)"))
    }

    @Test
    fun `parseOverpassJson classifies POIs and drops points outside active radius`() {
        val sampleJson = """
            {
              "elements": [
                {
                  "type": "node",
                  "id": 101,
                  "lat": -8.8155,
                  "lon": 13.2310,
                  "tags": { "name": "Paragem Mutamba", "highway": "bus_stop", "addr:street": "Av. 4 de Fevereiro" }
                },
                {
                  "type": "node",
                  "id": 102,
                  "lat": -8.8200,
                  "lon": 13.2350,
                  "tags": { "name": "Hospital Américo Boavida", "amenity": "hospital" }
                },
                {
                  "type": "way",
                  "id": 103,
                  "center": { "lat": -8.8220, "lon": 13.2400 },
                  "tags": { "name": "Mercado dos Congolenses", "amenity": "marketplace" }
                },
                {
                  "type": "node",
                  "id": 104,
                  "lat": -8.8180,
                  "lon": 13.2320,
                  "tags": { "name": "Banco BAI Mutamba", "amenity": "bank" }
                },
                {
                  "type": "node",
                  "id": 105,
                  "lat": -8.8260,
                  "lon": 13.2360,
                  "tags": { "name": "Escola Nzinga Mbandi", "amenity": "school" }
                },
                {
                  "type": "node",
                  "id": 106,
                  "lat": -8.8170,
                  "lon": 13.2290,
                  "tags": { "name": "Governo Provincial de Luanda", "amenity": "townhall" }
                },
                {
                  "type": "node",
                  "id": 999,
                  "lat": -9.0500,
                  "lon": 13.4500,
                  "tags": { "name": "Ponto Muito Distante", "amenity": "hospital" }
                }
              ]
            }
        """.trimIndent()

        val parsed = repo.parseOverpassJson(sampleJson, centerLat, centerLng, radiusKm = 5)
        assertEquals(6, parsed.size)
        assertEquals(PoiCategory.TAXI_STOP, parsed.first { it.name == "Paragem Mutamba" }.category)
        assertEquals("Av. 4 de Fevereiro", parsed.first { it.name == "Paragem Mutamba" }.subtitle)
        assertEquals(PoiCategory.HOSPITAL, parsed.first { it.name == "Hospital Américo Boavida" }.category)
        assertEquals(PoiCategory.MARKET, parsed.first { it.name == "Mercado dos Congolenses" }.category)
        assertEquals(PoiCategory.BANK, parsed.first { it.name == "Banco BAI Mutamba" }.category)
        assertEquals(PoiCategory.SCHOOL, parsed.first { it.name == "Escola Nzinga Mbandi" }.category)
        assertEquals(PoiCategory.INSTITUTION, parsed.first { it.name == "Governo Provincial de Luanda" }.category)
        assertTrue(parsed.none { it.name == "Ponto Muito Distante" })
    }
}
