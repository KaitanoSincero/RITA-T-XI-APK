package com.example

import com.example.util.GeoUtils
import com.example.util.MapRadiusKm
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GeoUtilsTest {

    // Reference GPS in Luanda (Mutamba)
    private val mutambaLat = -8.8147
    private val mutambaLng = 13.2302

    // ~3.5 km from Mutamba (Maianga / Kinaxixi area)
    private val closeLat = -8.8380
    private val closeLng = 13.2520

    // ~8.2 km from Mutamba (Benfica / Samba road)
    private val midLat = -8.8850
    private val midLng = 13.2080

    // ~13.5 km from Mutamba (Talatona)
    private val outer15Lat = -8.9280
    private val outer15Lng = 13.1850

    // ~18.5 km from Mutamba (Viana)
    private val outer20Lat = -8.9020
    private val outer20Lng = 13.3740

    // ~32 km away (outside max 20 km radius)
    private val farLat = -9.0500
    private val farLng = 13.4500

    @Test
    fun `radius presets match required 5, 10, 15 and 20 km bounds`() {
        assertEquals(listOf(5, 10, 15, 20), MapRadiusKm.entries.map { it.km })
        assertEquals(MapRadiusKm.KM_5, MapRadiusKm.DEFAULT)
        assertEquals(MapRadiusKm.KM_20, MapRadiusKm.MAX)
    }

    @Test
    fun `isWithinRadiusKm enforces 5, 10, 15 and 20 km thresholds accurately`() {
        // Inside 5 km
        assertTrue(GeoUtils.isWithinRadiusKm(mutambaLat, mutambaLng, closeLat, closeLng, 5))

        // Outside 5 km, inside 10 km
        assertFalse(GeoUtils.isWithinRadiusKm(mutambaLat, mutambaLng, midLat, midLng, 5))
        assertTrue(GeoUtils.isWithinRadiusKm(mutambaLat, mutambaLng, midLat, midLng, 10))

        // Outside 10 km, inside 15 km
        assertFalse(GeoUtils.isWithinRadiusKm(mutambaLat, mutambaLng, outer15Lat, outer15Lng, 10))
        assertTrue(GeoUtils.isWithinRadiusKm(mutambaLat, mutambaLng, outer15Lat, outer15Lng, 15))

        // Outside 15 km, inside 20 km
        assertFalse(GeoUtils.isWithinRadiusKm(mutambaLat, mutambaLng, outer20Lat, outer20Lng, 15))
        assertTrue(GeoUtils.isWithinRadiusKm(mutambaLat, mutambaLng, outer20Lat, outer20Lng, 20))

        // Beyond max 20 km radius
        assertFalse(GeoUtils.isWithinRadiusKm(mutambaLat, mutambaLng, farLat, farLng, 20))
    }

    @Test
    fun `boundingBox surrounds center symmetrically for 20 km`() {
        val bounds = GeoUtils.boundingBox(mutambaLat, mutambaLng, 20)
        assertTrue(bounds.minLat < mutambaLat && bounds.maxLat > mutambaLat)
        assertTrue(bounds.minLng < mutambaLng && bounds.maxLng > mutambaLng)
    }

    @Test
    fun `formatDistancePt formats meters and kilometers for Angola locale`() {
        assertEquals("450 m", GeoUtils.formatDistancePt(450.0))
        val kmFormatted = GeoUtils.formatDistancePt(2500.0)
        assertTrue(kmFormatted.endsWith("km"))
    }
}
