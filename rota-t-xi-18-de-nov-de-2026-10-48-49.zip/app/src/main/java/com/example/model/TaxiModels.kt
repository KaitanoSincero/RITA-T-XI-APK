package com.example.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp
import java.text.NumberFormat
import java.util.Locale

enum class TaxiStatus(val wireValue: String, val labelPt: String) {
    ACTIVE("ACTIVE", "Ativo"),
    INACTIVE("INACTIVE", "Inativo");

    companion object {
        fun fromRaw(raw: String?): TaxiStatus =
            entries.firstOrNull { it.wireValue.equals(raw, ignoreCase = true) } ?: INACTIVE
    }
}

enum class TaxiStopType(val wireValue: String, val labelPt: String) {
    TAXI_STOP("TAXI_STOP", "Paragem de Táxi"),
    TAXI_RANK("TAXI_RANK", "Ponto de Táxi");

    companion object {
        fun fromRaw(raw: String?): TaxiStopType =
            entries.firstOrNull { it.wireValue.equals(raw, ignoreCase = true) } ?: TAXI_STOP
    }
}

enum class PoiCategory(val code: String, val labelPt: String) {
    TAXI_STOP("TAXI_STOP", "Paragens"),
    HOSPITAL("HOSPITAL", "Hospitais"),
    SCHOOL("SCHOOL", "Escolas"),
    MARKET("MARKET", "Mercados"),
    BANK("BANK", "Bancos"),
    INSTITUTION("INSTITUTION", "Instituições")
}

data class MapPoi(
    val id: String,
    val name: String,
    val category: PoiCategory,
    val latitude: Double,
    val longitude: Double,
    val subtitle: String = "",
    val isRotaTaxiRegistered: Boolean = false
)

@Keep
@IgnoreExtraProperties
data class DriverProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val fullName: String = "",
    val phone: String = "",
    val vehicleModel: String = "",
    val vehicleColor: String = "",
    val licensePlate: String = "",
    val maxSeats: Long = 14L,
    val defaultRoute: String = LuandaTransitDefaults.DEFAULT_ROUTE,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class ActiveTaxi(
    @DocumentId val id: String = "",
    val driverId: String = "",
    val driverName: String = "",
    val vehicleModel: String = "",
    val vehicleColor: String = "",
    val licensePlate: String = "",
    val route: String = "",
    val availableSeats: Long = 0L,
    val maxSeats: Long = 14L,
    val status: String = TaxiStatus.INACTIVE.wireValue,
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val bearing: Double = 0.0,
    val speedKmh: Double = 0.0,
    val accuracyMeters: Double = 0.0,
    @get:PropertyName("hasGpsFix")
    @PropertyName("hasGpsFix")
    val hasGpsFix: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val parsedStatus: TaxiStatus
        get() = TaxiStatus.fromRaw(status)

    val isActive: Boolean
        get() = parsedStatus == TaxiStatus.ACTIVE
}

@Keep
@IgnoreExtraProperties
data class TaxiStop(
    @DocumentId val id: String = "",
    val createdBy: String = "",
    val name: String = "",
    val routeHint: String = "",
    val stopType: String = TaxiStopType.TAXI_STOP.wireValue,
    val status: String = TaxiStatus.ACTIVE.wireValue,
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val parsedType: TaxiStopType
        get() = TaxiStopType.fromRaw(stopType)
}

object LuandaTransitDefaults {
    const val LUANDA_CENTER_LAT = -8.8390
    const val LUANDA_CENTER_LNG = 13.2894
    const val DEFAULT_ROUTE = "Benfica → Mutamba"

    val POPULAR_LUANDA_ROUTES = listOf(
        "Benfica → Mutamba",
        "Viana → Congolenses",
        "Kilamba → Mutamba",
        "Cacuaco → São Paulo",
        "Talatona → Ilha de Luanda",
        "Maianga → Rocha Pinto",
        "Zango → Viana",
        "Hoji-ya-Henda → Congolenses"
    )

    val VEHICLE_MODELS = listOf(
        "Toyota Hiace",
        "Toyota Quantum",
        "Suzuki Carry",
        "Hyundai i10",
        "Kia Picanto"
    )

    fun formatAngolanKwanza(amount: Long): String {
        val formatter = NumberFormat.getNumberInstance(
            Locale.Builder().setLanguage("pt").setRegion("AO").build()
        )
        return "${formatter.format(amount)} Kz"
    }
}
