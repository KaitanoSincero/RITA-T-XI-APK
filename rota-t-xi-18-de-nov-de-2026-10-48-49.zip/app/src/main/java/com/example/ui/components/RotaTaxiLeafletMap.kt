package com.example.ui.components

import android.annotation.SuppressLint
import android.location.Location
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.example.model.ActiveTaxi
import com.example.model.MapPoi
import com.example.util.MapRadiusKm
import org.json.JSONArray
import org.json.JSONObject

data class MapFocusTarget(
    val latitude: Double,
    val longitude: Double,
    val zoom: Int = 15,
    val token: Long = System.nanoTime()
)

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun RotaTaxiLeafletMap(
    modifier: Modifier = Modifier,
    passengerLocation: Location?,
    selectedRadius: MapRadiusKm,
    taxis: List<ActiveTaxi>,
    pois: List<MapPoi>,
    selectedTaxiId: String?,
    selectedPoiId: String?,
    recenterTrigger: Long,
    radiusZoomTrigger: Long,
    focusTarget: MapFocusTarget?,
    onTaxiSelected: (String) -> Unit,
    onPoiSelected: (String) -> Unit,
    onMapCleared: () -> Unit,
    onMapLongPressed: (Double, Double) -> Unit
) {
    val latestOnTaxiSelected by rememberUpdatedState(onTaxiSelected)
    val latestOnPoiSelected by rememberUpdatedState(onPoiSelected)
    val latestOnMapCleared by rememberUpdatedState(onMapCleared)
    val latestOnMapLongPressed by rememberUpdatedState(onMapLongPressed)

    var isMapReady by remember { mutableStateOf(false) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    val payloadJson = remember(
        passengerLocation?.latitude,
        passengerLocation?.longitude,
        selectedRadius,
        taxis,
        pois,
        selectedTaxiId,
        selectedPoiId
    ) {
        buildMapStateJson(
            passengerLocation = passengerLocation,
            selectedRadius = selectedRadius,
            taxis = taxis,
            pois = pois,
            selectedTaxiId = selectedTaxiId,
            selectedPoiId = selectedPoiId
        )
    }

    LaunchedEffect(isMapReady, payloadJson) {
        val wv = webViewRef
        if (isMapReady && wv != null) {
            wv.evaluateJavascript("window.updateMapState($payloadJson);", null)
        }
    }

    LaunchedEffect(recenterTrigger) {
        val wv = webViewRef
        if (isMapReady && wv != null && recenterTrigger > 0L) {
            wv.evaluateJavascript("window.recenterOnPassenger(${selectedRadius.leafletZoom});", null)
        }
    }

    LaunchedEffect(radiusZoomTrigger) {
        val wv = webViewRef
        if (isMapReady && wv != null && radiusZoomTrigger > 0L) {
            wv.evaluateJavascript("window.setRadiusZoom(${selectedRadius.leafletZoom});", null)
        }
    }

    LaunchedEffect(focusTarget?.token) {
        val wv = webViewRef
        val target = focusTarget
        if (isMapReady && wv != null && target != null) {
            wv.evaluateJavascript(
                "window.focusCoordinate(${target.latitude}, ${target.longitude}, ${target.zoom});",
                null
            )
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            webViewRef?.apply {
                removeJavascriptInterface("RotaTaxiBridge")
                stopLoading()
                destroy()
            }
            webViewRef = null
        }
    }

    AndroidView(
        modifier = modifier,
        factory = { context ->
            WebView(context).apply {
                setLayerType(View.LAYER_TYPE_HARDWARE, null)
                setBackgroundColor(0xFF16191F.toInt())
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    allowFileAccess = true
                    cacheMode = WebSettings.LOAD_DEFAULT
                    useWideViewPort = true
                    loadWithOverviewMode = true
                }
                webChromeClient = WebChromeClient()
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(
                        view: WebView?,
                        request: android.webkit.WebResourceRequest?
                    ): Boolean {
                        val url = request?.url?.toString().orEmpty()
                        return !url.startsWith("file:///android_asset/leaflet/")
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        super.onPageFinished(view, url)
                        isMapReady = true
                    }
                }

                addJavascriptInterface(
                    object {
                        @JavascriptInterface
                        fun onMapReady() {
                            mainHandler.post { isMapReady = true }
                        }

                        @JavascriptInterface
                        fun onTaxiSelected(driverId: String) {
                            mainHandler.post { latestOnTaxiSelected(driverId) }
                        }

                        @JavascriptInterface
                        fun onPoiSelected(poiId: String) {
                            mainHandler.post { latestOnPoiSelected(poiId) }
                        }

                        @JavascriptInterface
                        fun onMapCleared() {
                            mainHandler.post { latestOnMapCleared() }
                        }

                        @JavascriptInterface
                        fun onMapLongPressed(lat: Double, lng: Double) {
                            mainHandler.post { latestOnMapLongPressed(lat, lng) }
                        }
                    },
                    "RotaTaxiBridge"
                )

                loadUrl("file:///android_asset/leaflet/rotataxi_map.html")
                webViewRef = this
            }
        }
    )
}

private fun buildMapStateJson(
    passengerLocation: Location?,
    selectedRadius: MapRadiusKm,
    taxis: List<ActiveTaxi>,
    pois: List<MapPoi>,
    selectedTaxiId: String?,
    selectedPoiId: String?
): String {
    val root = JSONObject()
    root.put("hasPassengerLocation", passengerLocation != null)
    if (passengerLocation != null) {
        root.put("passengerLat", passengerLocation.latitude)
        root.put("passengerLng", passengerLocation.longitude)
    }
    root.put("radiusMeters", selectedRadius.meters)
    root.put("targetZoom", selectedRadius.leafletZoom)
    root.put("selectedTaxiId", selectedTaxiId ?: JSONObject.NULL)
    root.put("selectedPoiId", selectedPoiId ?: JSONObject.NULL)

    val taxisJson = JSONArray()
    taxis.forEach { taxi ->
        taxisJson.put(
            JSONObject().apply {
                put("driverId", taxi.driverId)
                put("driverName", taxi.driverName)
                put("route", taxi.route)
                put("availableSeats", taxi.availableSeats)
                put("maxSeats", taxi.maxSeats)
                put("latitude", taxi.latitude)
                put("longitude", taxi.longitude)
                put("vehicleModel", taxi.vehicleModel)
            }
        )
    }
    root.put("taxis", taxisJson)

    val poisJson = JSONArray()
    pois.forEach { poi ->
        poisJson.put(
            JSONObject().apply {
                put("id", poi.id)
                put("name", poi.name)
                put("category", poi.category.code)
                put("latitude", poi.latitude)
                put("longitude", poi.longitude)
                put("isRotaTaxiRegistered", poi.isRotaTaxiRegistered)
            }
        )
    }
    root.put("pois", poisJson)

    return root.toString()
}
