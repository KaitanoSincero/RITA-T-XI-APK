package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.R
import com.example.data.LocationTracker
import com.example.data.TaxiRepository
import com.example.data.authStateFlow
import com.example.ui.driver.DriverViewModel
import com.example.ui.passenger.PassengerViewModel
import com.example.ui.screens.DriverDashboardScreen
import com.example.ui.screens.PassengerDashboardScreen
import com.example.ui.screens.WelcomeAndAuthScreen
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.serialization.Serializable

@Serializable
data object HomeRoute

@Serializable
data object DriverRoute

@Serializable
data object PassengerRoute

@Composable
fun RotaTaxiAppNavigation(auth: FirebaseAuth = Firebase.auth) {
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val user = currentUser

    if (user == null) {
        // Unauthenticated gate: feature ViewModels and Firestore listeners are NOT instantiated.
        WelcomeAndAuthScreen(
            currentUser = null,
            onNavigateToDriver = {},
            onNavigateToPassenger = {},
            onAuthSuccess = {}
        )
    } else {
        // Key composition by uid so signing out or switching accounts disposes listeners cleanly.
        key(user.uid) {
            AuthenticatedNavGraph(user = user)
        }
    }
}

@Composable
private fun AuthenticatedNavGraph(user: FirebaseUser) {
    val navController = rememberNavController()
    val uid = user.uid
    val displayName = user.displayName.orEmpty()

    NavHost(
        navController = navController,
        startDestination = HomeRoute
    ) {
        composable<HomeRoute> {
            WelcomeAndAuthScreen(
                currentUser = user,
                onNavigateToDriver = { navController.navigate(DriverRoute) },
                onNavigateToPassenger = { navController.navigate(PassengerRoute) },
                onAuthSuccess = {}
            )
        }

        composable<DriverRoute> {
            val driverViewModel: DriverViewModel = viewModel(
                key = "driver_$uid",
                factory = viewModelFactory {
                    initializer {
                        val app = checkNotNull(this[APPLICATION_KEY]) {
                            "APPLICATION_KEY missing from CreationExtras"
                        }
                        val dbId = app.getString(R.string.firestore_database_id)
                        val db = FirebaseFirestore.getInstance(dbId)
                        DriverViewModel(
                            repository = TaxiRepository(db),
                            locationTracker = LocationTracker(app),
                            currentUserId = uid,
                            defaultDisplayName = displayName
                        )
                    }
                }
            )
            DriverDashboardScreen(
                viewModel = driverViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable<PassengerRoute> {
            val passengerViewModel: PassengerViewModel = viewModel(
                key = "passenger_$uid",
                factory = viewModelFactory {
                    initializer {
                        val app = checkNotNull(this[APPLICATION_KEY]) {
                            "APPLICATION_KEY missing from CreationExtras"
                        }
                        val dbId = app.getString(R.string.firestore_database_id)
                        val db = FirebaseFirestore.getInstance(dbId)
                        PassengerViewModel(
                            repository = TaxiRepository(db),
                            locationTracker = LocationTracker(app)
                        )
                    }
                }
            )
            PassengerDashboardScreen(
                viewModel = passengerViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
