package com.example.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.EventSeat
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.GpsNotFixed
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.model.LuandaTransitDefaults
import com.example.ui.driver.DriverDashboardData
import com.example.ui.driver.DriverFormState
import com.example.ui.driver.DriverViewModel
import com.example.ui.state.UiState
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.EmeraldActive
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.TaxiGold
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun DriverDashboardScreen(
    viewModel: DriverViewModel,
    onNavigateBack: () -> Unit
) {
    val dashboardState by viewModel.dashboardState.collectAsStateWithLifecycle()
    val formState by viewModel.formState.collectAsStateWithLifecycle()

    var startAfterPermission by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        viewModel.onPermissionResult(granted)
        if (granted && startAfterPermission) {
            startAfterPermission = false
            viewModel.startTrip()
        } else {
            startAfterPermission = false
        }
    }

    val activeTaxi = (dashboardState as? UiState.Success<DriverDashboardData>)?.data?.activeTaxi
    val isTripActive = activeTaxi?.isActive == true

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = stringResource(R.string.driver_dashboard_title),
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = if (isTripActive) "Viagem em curso" else "Pronto para iniciar",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isTripActive) EmeraldActive else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("btn_driver_back")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.cd_back)
                        )
                    }
                },
                actions = {
                    Surface(
                        color = if (isTripActive) MaterialTheme.colorScheme.tertiaryContainer
                        else MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(50),
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(if (isTripActive) EmeraldActive else Color.Gray)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isTripActive) stringResource(R.string.status_active)
                                else stringResource(R.string.status_inactive),
                                style = MaterialTheme.typography.labelMedium,
                                color = if (isTripActive) MaterialTheme.colorScheme.onTertiaryContainer
                                else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        when (val state = dashboardState) {
            is UiState.Loading -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }

            is UiState.Error -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer
                        )
                    ) {
                        Text(
                            text = state.message,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(20.dp)
                        )
                    }
                }
            }

            is UiState.Success -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    contentAlignment = Alignment.TopCenter
                ) {
                    Column(
                        modifier = Modifier
                            .widthIn(max = 680.dp)
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .navigationBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Feedback Banners
                        AnimatedVisibility(visible = formState.errorMessage != null) {
                            Surface(
                                color = MaterialTheme.colorScheme.errorContainer,
                                shape = MaterialTheme.shapes.medium,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = formState.errorMessage ?: "",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    modifier = Modifier.padding(14.dp)
                                )
                            }
                        }

                        AnimatedVisibility(visible = formState.statusMessage != null) {
                            Surface(
                                color = MaterialTheme.colorScheme.tertiaryContainer,
                                shape = MaterialTheme.shapes.medium,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.CheckCircle,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onTertiaryContainer,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = formState.statusMessage ?: "",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onTertiaryContainer
                                    )
                                }
                            }
                        }

                        // Live Trip & GPS Status Card
                        TripStatusBannerCard(
                            isTripActive = isTripActive,
                            route = activeTaxi?.route?.takeIf { isTripActive } ?: formState.effectiveRoute,
                            availableSeats = if (isTripActive) {
                                activeTaxi?.availableSeats?.toInt() ?: formState.availableSeats
                            } else {
                                formState.availableSeats
                            },
                            formState = formState
                        )

                        // Seats & Start/End Trip Controls
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = MaterialTheme.shapes.large,
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(18.dp),
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Filled.EventSeat,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(
                                                text = stringResource(R.string.seats_title),
                                                style = MaterialTheme.typography.titleMedium
                                            )
                                            Text(
                                                text = "Lotação máxima: ${formState.maxSeats}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        FilledTonalIconButton(
                                            onClick = { viewModel.adjustAvailableSeats(-1) },
                                            enabled = formState.availableSeats > 0,
                                            modifier = Modifier
                                                .size(48.dp)
                                                .testTag("btn_seats_minus")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.Remove,
                                                contentDescription = "Diminuir lugares"
                                            )
                                        }

                                        Text(
                                            text = "${formState.availableSeats}",
                                            style = MaterialTheme.typography.headlineMedium,
                                            fontWeight = FontWeight.ExtraBold,
                                            modifier = Modifier.padding(horizontal = 4.dp)
                                        )

                                        FilledTonalIconButton(
                                            onClick = { viewModel.adjustAvailableSeats(1) },
                                            enabled = formState.availableSeats < formState.maxSeats,
                                            modifier = Modifier
                                                .size(48.dp)
                                                .testTag("btn_seats_plus")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.Add,
                                                contentDescription = "Aumentar lugares"
                                            )
                                        }
                                    }
                                }

                                HorizontalDivider()

                                if (!isTripActive) {
                                    Button(
                                        onClick = {
                                            if (formState.hasLocationPermission) {
                                                viewModel.startTrip()
                                            } else {
                                                startAfterPermission = true
                                                permissionLauncher.launch(
                                                    arrayOf(
                                                        Manifest.permission.ACCESS_FINE_LOCATION,
                                                        Manifest.permission.ACCESS_COARSE_LOCATION
                                                    )
                                                )
                                            }
                                        },
                                        enabled = !formState.isTripSubmitting,
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = EmeraldActive,
                                            contentColor = Color.White
                                        ),
                                        shape = MaterialTheme.shapes.medium,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(56.dp)
                                            .testTag("btn_start_trip")
                                    ) {
                                        if (formState.isTripSubmitting) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(22.dp),
                                                color = Color.White,
                                                strokeWidth = 2.5.dp
                                            )
                                        } else {
                                            Icon(
                                                imageVector = Icons.Filled.PlayArrow,
                                                contentDescription = null
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = stringResource(R.string.btn_start_trip),
                                                style = MaterialTheme.typography.titleMedium
                                            )
                                        }
                                    }
                                } else {
                                    Button(
                                        onClick = { viewModel.endTrip() },
                                        enabled = !formState.isTripSubmitting,
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = CrimsonAlert,
                                            contentColor = Color.White
                                        ),
                                        shape = MaterialTheme.shapes.medium,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(56.dp)
                                            .testTag("btn_end_trip")
                                    ) {
                                        if (formState.isTripSubmitting) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(22.dp),
                                                color = Color.White,
                                                strokeWidth = 2.5.dp
                                            )
                                        } else {
                                            Icon(
                                                imageVector = Icons.Filled.Stop,
                                                contentDescription = null
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = stringResource(R.string.btn_end_trip),
                                                style = MaterialTheme.typography.titleMedium
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Route Selection Card
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = MaterialTheme.shapes.large,
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(18.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Filled.Route,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = stringResource(R.string.route_selection_title),
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                }

                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    LuandaTransitDefaults.POPULAR_LUANDA_ROUTES.forEach { route ->
                                        FilterChip(
                                            selected = !formState.useCustomRoute && formState.selectedRoute == route,
                                            onClick = { viewModel.selectPresetRoute(route) },
                                            label = { Text(route) }
                                        )
                                    }
                                    FilterChip(
                                        selected = formState.useCustomRoute,
                                        onClick = { viewModel.enableCustomRoute() },
                                        label = { Text("Outra rota") }
                                    )
                                }

                                AnimatedVisibility(visible = formState.useCustomRoute) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        OutlinedTextField(
                                            value = formState.customOrigin,
                                            onValueChange = viewModel::updateCustomOrigin,
                                            label = { Text("Origem") },
                                            placeholder = { Text("Ex: Benfica") },
                                            singleLine = true,
                                            modifier = Modifier.weight(1f)
                                        )
                                        OutlinedTextField(
                                            value = formState.customDestination,
                                            onValueChange = viewModel::updateCustomDestination,
                                            label = { Text("Destino") },
                                            placeholder = { Text("Ex: Mutamba") },
                                            singleLine = true,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }
                        }

                        // Driver Registration & Vehicle Info Card
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = MaterialTheme.shapes.large,
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(18.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Filled.Person,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = stringResource(R.string.driver_registration_title),
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                }

                                OutlinedTextField(
                                    value = formState.fullName,
                                    onValueChange = viewModel::updateFullName,
                                    label = { Text("Nome completo do motorista") },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("input_driver_name")
                                )

                                OutlinedTextField(
                                    value = formState.phone,
                                    onValueChange = viewModel::updatePhone,
                                    label = { Text("Telefone (+244)") },
                                    placeholder = { Text("+244 923 000 000") },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("input_driver_phone")
                                )

                                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Filled.DirectionsCar,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = stringResource(R.string.vehicle_info_title),
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                }

                                OutlinedTextField(
                                    value = formState.vehicleModel,
                                    onValueChange = viewModel::updateVehicleModel,
                                    label = { Text("Modelo do veículo") },
                                    placeholder = { Text("Ex: Toyota Hiace") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("input_vehicle_model")
                                )

                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    LuandaTransitDefaults.VEHICLE_MODELS.forEach { model ->
                                        FilterChip(
                                            selected = formState.vehicleModel.equals(model, ignoreCase = true),
                                            onClick = { viewModel.updateVehicleModel(model) },
                                            label = { Text(model) }
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    OutlinedTextField(
                                        value = formState.vehicleColor,
                                        onValueChange = viewModel::updateVehicleColor,
                                        label = { Text("Cor") },
                                        placeholder = { Text("Azul e Branco") },
                                        singleLine = true,
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("input_vehicle_color")
                                    )

                                    OutlinedTextField(
                                        value = formState.licensePlate,
                                        onValueChange = viewModel::updateLicensePlate,
                                        label = { Text("Matrícula") },
                                        placeholder = { Text("LD-45-89-AB") },
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("input_license_plate")
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Lotação máxima de passageiros",
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        FilledTonalIconButton(
                                            onClick = { viewModel.updateMaxSeats(formState.maxSeats - 1) },
                                            enabled = formState.maxSeats > 1,
                                            modifier = Modifier.size(48.dp)
                                        ) {
                                            Icon(Icons.Filled.Remove, contentDescription = "Reduzir lotação")
                                        }
                                        Text(
                                            text = "${formState.maxSeats}",
                                            style = MaterialTheme.typography.titleMedium
                                        )
                                        FilledTonalIconButton(
                                            onClick = { viewModel.updateMaxSeats(formState.maxSeats + 1) },
                                            enabled = formState.maxSeats < 30,
                                            modifier = Modifier.size(48.dp)
                                        ) {
                                            Icon(Icons.Filled.Add, contentDescription = "Aumentar lotação")
                                        }
                                    }
                                }

                                FilledTonalButton(
                                    onClick = { viewModel.saveProfile() },
                                    enabled = !formState.isSavingProfile,
                                    contentPadding = PaddingValues(vertical = 14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("btn_save_profile")
                                ) {
                                    if (formState.isSavingProfile) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(20.dp),
                                            strokeWidth = 2.dp
                                        )
                                    } else {
                                        Icon(Icons.Filled.Save, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(stringResource(R.string.btn_save_profile))
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun TripStatusBannerCard(
    isTripActive: Boolean,
    route: String,
    availableSeats: Int,
    formState: DriverFormState
) {
    val containerColor = if (isTripActive) NavyDeep else MaterialTheme.colorScheme.surfaceVariant
    val contentColor = if (isTripActive) Color.White else MaterialTheme.colorScheme.onSurface

    Card(
        colors = CardDefaults.cardColors(
            containerColor = containerColor,
            contentColor = contentColor
        ),
        shape = MaterialTheme.shapes.large,
        elevation = CardDefaults.cardElevation(defaultElevation = if (isTripActive) 4.dp else 0.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Rota atual",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isTripActive) TaxiGold else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = route.ifBlank { "Selecione uma rota" },
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    color = if (isTripActive) EmeraldActive else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = if (isTripActive) "Estado: Ativo" else "Estado: Inativo",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (isTripActive) Color.White else contentColor,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Lugares disponíveis: $availableSeats",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )

                val gpsLoc = formState.lastGpsLocation
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isTripActive && gpsLoc != null) Icons.Filled.GpsFixed else Icons.Filled.GpsNotFixed,
                        contentDescription = null,
                        tint = if (isTripActive && gpsLoc != null) TaxiGold else contentColor.copy(alpha = 0.7f),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    val gpsText = when {
                        !isTripActive -> "GPS desligado"
                        gpsLoc != null -> String.format(
                            Locale.US,
                            "%.4f, %.4f (±%.0fm)",
                            gpsLoc.latitude,
                            gpsLoc.longitude,
                            gpsLoc.accuracy
                        )
                        else -> stringResource(R.string.gps_waiting_fix)
                    }
                    Text(
                        text = gpsText,
                        style = MaterialTheme.typography.bodySmall,
                        color = contentColor.copy(alpha = 0.85f)
                    )
                }
            }
        }
    }
}
