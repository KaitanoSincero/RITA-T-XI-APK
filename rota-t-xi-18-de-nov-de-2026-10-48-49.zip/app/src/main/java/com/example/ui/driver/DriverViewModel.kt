package com.example.ui.driver

import android.location.Location
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.LocationTracker
import com.example.data.TaxiRepository
import com.example.model.ActiveTaxi
import com.example.model.DriverProfile
import com.example.model.LuandaTransitDefaults
import com.example.ui.state.UiState
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class DriverFormState(
    val fullName: String = "",
    val phone: String = "",
    val vehicleModel: String = "Toyota Hiace",
    val vehicleColor: String = "Azul e Branco",
    val licensePlate: String = "",
    val maxSeats: Int = 14,
    val selectedRoute: String = LuandaTransitDefaults.DEFAULT_ROUTE,
    val customOrigin: String = "",
    val customDestination: String = "",
    val useCustomRoute: Boolean = false,
    val availableSeats: Int = 3,
    val isProfileLoaded: Boolean = false,
    val isSavingProfile: Boolean = false,
    val isTripSubmitting: Boolean = false,
    val hasLocationPermission: Boolean = false,
    val isSharingGps: Boolean = false,
    val lastGpsLocation: Location? = null,
    val lastGpsUpdateEpochMs: Long? = null,
    val statusMessage: String? = null,
    val errorMessage: String? = null
) {
    val effectiveRoute: String
        get() = if (useCustomRoute) {
            val o = customOrigin.trim()
            val d = customDestination.trim()
            if (o.isNotEmpty() && d.isNotEmpty()) "$o → $d" else ""
        } else {
            selectedRoute
        }
}

data class DriverDashboardData(
    val profile: DriverProfile? = null,
    val activeTaxi: ActiveTaxi? = null
)

class DriverViewModel(
    private val repository: TaxiRepository,
    private val locationTracker: LocationTracker,
    private val currentUserId: String,
    defaultDisplayName: String
) : ViewModel() {

    private val _formState = MutableStateFlow(
        DriverFormState(
            fullName = defaultDisplayName.trim(),
            hasLocationPermission = locationTracker.hasLocationPermission()
        )
    )
    val formState: StateFlow<DriverFormState> = _formState.asStateFlow()

    private var gpsJob: Job? = null

    val dashboardState: StateFlow<UiState<DriverDashboardData>> = combine(
        repository.observeDriverProfile(currentUserId),
        repository.observeOwnTaxi(currentUserId)
    ) { profile, taxi ->
        syncFromSnapshot(profile, taxi)
        UiState.Success(DriverDashboardData(profile = profile, activeTaxi = taxi)) as UiState<DriverDashboardData>
    }.catch { error ->
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val rootError = firestoreError ?: error
        Log.w(TAG, "Error observing driver dashboard", rootError)
        emit(UiState.Error(rootError.message ?: "Erro ao carregar dados do motorista."))
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = UiState.Loading
    )

    private fun syncFromSnapshot(profile: DriverProfile?, taxi: ActiveTaxi?) {
        _formState.update { current ->
            var next = current
            if (!current.isProfileLoaded && profile != null) {
                val isPreset = LuandaTransitDefaults.POPULAR_LUANDA_ROUTES.contains(profile.defaultRoute)
                val parts = profile.defaultRoute.split("→").map { it.trim() }
                next = next.copy(
                    fullName = profile.fullName,
                    phone = profile.phone,
                    vehicleModel = profile.vehicleModel,
                    vehicleColor = profile.vehicleColor,
                    licensePlate = profile.licensePlate,
                    maxSeats = profile.maxSeats.toInt().coerceIn(1, 30),
                    selectedRoute = if (isPreset) profile.defaultRoute else LuandaTransitDefaults.DEFAULT_ROUTE,
                    useCustomRoute = !isPreset,
                    customOrigin = if (!isPreset && parts.size == 2) parts[0] else "",
                    customDestination = if (!isPreset && parts.size == 2) parts[1] else "",
                    availableSeats = current.availableSeats.coerceIn(0, profile.maxSeats.toInt().coerceIn(1, 30)),
                    isProfileLoaded = true
                )
            } else if (!current.isProfileLoaded && profile == null) {
                next = next.copy(isProfileLoaded = true)
            }

            if (taxi != null && taxi.isActive) {
                next = next.copy(
                    availableSeats = taxi.availableSeats.toInt().coerceIn(0, taxi.maxSeats.toInt().coerceIn(1, 30))
                )
            }
            next
        }

        if (taxi != null && taxi.isActive && locationTracker.hasLocationPermission() && gpsJob?.isActive != true) {
            startGpsStreaming()
        } else if ((taxi == null || !taxi.isActive) && gpsJob?.isActive == true) {
            stopGpsStreaming()
        }
    }

    fun onPermissionResult(granted: Boolean) {
        _formState.update {
            it.copy(
                hasLocationPermission = granted || locationTracker.hasLocationPermission(),
                errorMessage = if (!granted && !locationTracker.hasLocationPermission()) {
                    "Permissão de GPS necessária para partilhar localização em tempo real."
                } else null
            )
        }
        val currentTaxi = (dashboardState.value as? UiState.Success)?.data?.activeTaxi
        if ((granted || locationTracker.hasLocationPermission()) && currentTaxi?.isActive == true) {
            startGpsStreaming()
        }
    }

    fun updateFullName(value: String) = _formState.update { it.copy(fullName = value, errorMessage = null) }
    fun updatePhone(value: String) = _formState.update { it.copy(phone = value, errorMessage = null) }
    fun updateVehicleModel(value: String) = _formState.update { it.copy(vehicleModel = value, errorMessage = null) }
    fun updateVehicleColor(value: String) = _formState.update { it.copy(vehicleColor = value, errorMessage = null) }
    fun updateLicensePlate(value: String) = _formState.update { it.copy(licensePlate = value, errorMessage = null) }
    fun updateCustomOrigin(value: String) = _formState.update { it.copy(customOrigin = value, errorMessage = null) }
    fun updateCustomDestination(value: String) = _formState.update { it.copy(customDestination = value, errorMessage = null) }

    fun selectPresetRoute(route: String) {
        _formState.update {
            it.copy(
                selectedRoute = route,
                useCustomRoute = false,
                errorMessage = null
            )
        }
    }

    fun enableCustomRoute() {
        _formState.update { it.copy(useCustomRoute = true, errorMessage = null) }
    }

    fun updateMaxSeats(newMax: Int) {
        val clamped = newMax.coerceIn(1, 30)
        _formState.update {
            it.copy(
                maxSeats = clamped,
                availableSeats = it.availableSeats.coerceIn(0, clamped),
                errorMessage = null
            )
        }
    }

    fun adjustAvailableSeats(delta: Int) {
        val state = _formState.value
        val newSeats = (state.availableSeats + delta).coerceIn(0, state.maxSeats)
        if (newSeats == state.availableSeats) return
        _formState.update { it.copy(availableSeats = newSeats, errorMessage = null) }

        val activeTaxi = (dashboardState.value as? UiState.Success)?.data?.activeTaxi
        if (activeTaxi?.isActive == true) {
            viewModelScope.launch {
                val result = repository.updateAvailableSeats(currentUserId, newSeats)
                result.onFailure { err ->
                    _formState.update {
                        it.copy(errorMessage = err.localizedMessage ?: "Não foi possível atualizar os lugares.")
                    }
                }
            }
        }
    }

    fun saveProfile() {
        val state = _formState.value
        val validationError = validateProfileFields(state)
        if (validationError != null) {
            _formState.update { it.copy(errorMessage = validationError, statusMessage = null) }
            return
        }

        viewModelScope.launch {
            _formState.update { it.copy(isSavingProfile = true, errorMessage = null, statusMessage = null) }
            val result = repository.saveDriverProfile(
                userId = currentUserId,
                fullName = state.fullName,
                phone = state.phone,
                vehicleModel = state.vehicleModel,
                vehicleColor = state.vehicleColor,
                licensePlate = state.licensePlate,
                maxSeats = state.maxSeats,
                defaultRoute = state.effectiveRoute
            )
            result.fold(
                onSuccess = {
                    _formState.update {
                        it.copy(
                            isSavingProfile = false,
                            statusMessage = "Perfil e veículo guardados com sucesso."
                        )
                    }
                },
                onFailure = { err ->
                    _formState.update {
                        it.copy(
                            isSavingProfile = false,
                            errorMessage = err.localizedMessage ?: "Falha ao guardar perfil."
                        )
                    }
                }
            )
        }
    }

    fun startTrip() {
        val state = _formState.value
        val validationError = validateProfileFields(state)
        if (validationError != null) {
            _formState.update { it.copy(errorMessage = validationError, statusMessage = null) }
            return
        }
        if (!locationTracker.hasLocationPermission()) {
            _formState.update {
                it.copy(
                    hasLocationPermission = false,
                    errorMessage = "Conceda permissão de localização GPS antes de iniciar a viagem."
                )
            }
            return
        }

        viewModelScope.launch {
            _formState.update { it.copy(isTripSubmitting = true, errorMessage = null, statusMessage = null) }

            // Ensure driver registration profile is persisted
            val profileResult = repository.saveDriverProfile(
                userId = currentUserId,
                fullName = state.fullName,
                phone = state.phone,
                vehicleModel = state.vehicleModel,
                vehicleColor = state.vehicleColor,
                licensePlate = state.licensePlate,
                maxSeats = state.maxSeats,
                defaultRoute = state.effectiveRoute
            )
            if (profileResult.isFailure) {
                _formState.update {
                    it.copy(
                        isTripSubmitting = false,
                        errorMessage = profileResult.exceptionOrNull()?.localizedMessage
                            ?: "Erro ao validar registo do motorista."
                    )
                }
                return@launch
            }

            // Obtain real device GPS fix if already available (never invent coordinates)
            val realLocation = locationTracker.getCurrentLocation()

            val tripResult = repository.startOrUpdateTrip(
                driverId = currentUserId,
                driverName = state.fullName,
                vehicleModel = state.vehicleModel,
                vehicleColor = state.vehicleColor,
                licensePlate = state.licensePlate,
                route = state.effectiveRoute,
                availableSeats = state.availableSeats,
                maxSeats = state.maxSeats,
                initialLocation = realLocation
            )

            tripResult.fold(
                onSuccess = {
                    _formState.update {
                        it.copy(
                            isTripSubmitting = false,
                            lastGpsLocation = realLocation ?: it.lastGpsLocation,
                            lastGpsUpdateEpochMs = if (realLocation != null) System.currentTimeMillis() else it.lastGpsUpdateEpochMs,
                            statusMessage = if (realLocation != null) {
                                "Viagem ativa! Localização GPS a ser partilhada."
                            } else {
                                "Viagem ativa! A aguardar sinal GPS do dispositivo…"
                            }
                        )
                    }
                    startGpsStreaming()
                },
                onFailure = { err ->
                    _formState.update {
                        it.copy(
                            isTripSubmitting = false,
                            errorMessage = err.localizedMessage ?: "Não foi possível iniciar a viagem."
                        )
                    }
                }
            )
        }
    }

    fun endTrip() {
        stopGpsStreaming()
        viewModelScope.launch {
            _formState.update { it.copy(isTripSubmitting = true, errorMessage = null, statusMessage = null) }
            val result = repository.endTrip(currentUserId)
            result.fold(
                onSuccess = {
                    _formState.update {
                        it.copy(
                            isTripSubmitting = false,
                            isSharingGps = false,
                            statusMessage = "Viagem terminada. Partilha GPS desativada."
                        )
                    }
                },
                onFailure = { err ->
                    _formState.update {
                        it.copy(
                            isTripSubmitting = false,
                            errorMessage = err.localizedMessage ?: "Erro ao terminar viagem."
                        )
                    }
                }
            )
        }
    }

    fun clearBanner() {
        _formState.update { it.copy(errorMessage = null, statusMessage = null) }
    }

    private fun startGpsStreaming() {
        if (gpsJob?.isActive == true) return
        if (!locationTracker.hasLocationPermission()) return

        _formState.update { it.copy(isSharingGps = true) }
        var lastPushedLocation: Location? = null
        var lastPushedTimeMs = 0L

        gpsJob = viewModelScope.launch {
            locationTracker.observeLocationUpdates(intervalMillis = 5000L)
                .catch { err ->
                    Log.w(TAG, "GPS stream stopped: ${err.message}", err)
                    _formState.update {
                        it.copy(
                            isSharingGps = false,
                            errorMessage = "Sinal GPS interrompido: ${err.localizedMessage ?: "verifique o GPS"}"
                        )
                    }
                }
                .collect { location ->
                    val now = System.currentTimeMillis()
                    _formState.update {
                        it.copy(
                            isSharingGps = true,
                            lastGpsLocation = location,
                            lastGpsUpdateEpochMs = now
                        )
                    }
                    val prev = lastPushedLocation
                    val movedEnough = prev == null || prev.distanceTo(location) >= 12f
                    val elapsedEnough = (now - lastPushedTimeMs) >= 8000L
                    if (movedEnough || elapsedEnough) {
                        lastPushedLocation = location
                        lastPushedTimeMs = now
                        repository.updateTaxiLocation(currentUserId, location)
                    }
                }
        }
    }

    private fun stopGpsStreaming() {
        gpsJob?.cancel()
        gpsJob = null
        _formState.update { it.copy(isSharingGps = false) }
    }

    private fun validateProfileFields(state: DriverFormState): String? {
        if (state.fullName.trim().length < 2) return "Informe o nome do motorista (mínimo 2 caracteres)."
        if (state.phone.trim().length < 6) return "Informe o número de telefone (ex: +244 923 000 000)."
        if (state.vehicleModel.trim().length < 2) return "Informe o modelo do veículo (ex: Toyota Hiace)."
        if (state.vehicleColor.trim().length < 2) return "Informe a cor do veículo (ex: Azul e Branco)."
        if (state.licensePlate.trim().length < 3) return "Informe a matrícula do veículo (ex: LD-45-89-AB)."
        if (state.effectiveRoute.trim().length < 3) return "Selecione ou defina uma rota (Origem → Destino)."
        return null
    }

    override fun onCleared() {
        super.onCleared()
        stopGpsStreaming()
    }

    private companion object {
        const val TAG = "DriverViewModel"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
