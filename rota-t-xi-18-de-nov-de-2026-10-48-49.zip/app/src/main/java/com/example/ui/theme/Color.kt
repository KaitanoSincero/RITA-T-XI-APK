package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Luanda Transit Brand Palette — Deep Atlantic Navy, Cobalt Blue & Warm Taxi Gold
val NavyDeep = Color(0xFF0B2A47)
val NavyContainer = Color(0xFF143D66)
val CobaltBlue = Color(0xFF155EEF)
val CobaltContainer = Color(0xFFDCE7FF)
val OnCobaltContainer = Color(0xFF001B4D)

val TaxiGold = Color(0xFFF59E0B)
val TaxiGoldDark = Color(0xFFD97706)
val TaxiGoldContainer = Color(0xFFFEF3C7)
val OnTaxiGoldContainer = Color(0xFF451A03)

val EmeraldActive = Color(0xFF059669)
val EmeraldContainer = Color(0xFFD1FAE5)
val OnEmeraldContainer = Color(0xFF022C22)

val CrimsonAlert = Color(0xFFDC2626)
val CrimsonContainer = Color(0xFFFEE2E2)
val OnCrimsonContainer = Color(0xFF450A0A)

// Light Surfaces
val LightBackground = Color(0xFFF6F8FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE9EFF6)
val LightOnSurface = Color(0xFF0F172A)
val LightOnSurfaceVariant = Color(0xFF475569)
val LightOutline = Color(0xFFCBD5E1)

// Dark Surfaces
val DarkBackground = Color(0xFF071526)
val DarkSurface = Color(0xFF0D2138)
val DarkSurfaceVariant = Color(0xFF163252)
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
val DarkOutline = Color(0xFF28476B)

// Map HUD Dark Mobility Palette (Reference Image Style)
val HudDarkBackground = Color(0xFF11141B)
val HudDarkSurface = Color(0xEB151922)
val HudDarkElevated = Color(0xF21D2330)
val HudBorderSubtle = Color(0x2EFFFFFF)
val HudEmerald = Color(0xFF22C55E)
val HudBeaconYellow = Color(0xFFFACC15)
val HudHospitalRed = Color(0xFFEF4444)
val HudSchoolBlue = Color(0xFF38BDF8)
val HudBankPurple = Color(0xFFA855F7)
