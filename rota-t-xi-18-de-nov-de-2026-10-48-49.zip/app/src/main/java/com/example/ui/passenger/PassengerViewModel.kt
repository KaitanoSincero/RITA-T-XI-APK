package com.example.ui.passenger

import android.location.Location
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.LocationSource
import com.example.data.OsmPoiDataSource
import com.example.data.OsmPoiRepository
import com.example.data.TaxiDataSource
import com.example.model.ActiveTaxi
import com.example.model.MapPoi
import com.example.model.PoiCategory
import com.example.model.TaxiStop
import com.example.model.TaxiStopType
import com.example.ui.state.UiState
import com.example.util.GeoUtils
import com.example.util.MapRadiusKm
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PassengerFilterState(
    val selectedRadius: MapRadiusKm = MapRadiusKm.DEFAULT,
    val selectedRoute: String? = null,
    val searchQuery: String = "",
    val selectedTaxiId: String? = null,
    val selectedPoiId: String? = null,
    val hasLocationPermission: Boolean = false,
    val passengerLocation: Location? = null,
    val isLocatingGps: Boolean = false,
    val isLoadingPois: Boolean = false,
    val showListSheet: Boolean = false,
    val showExpandAreaMenu: Boolean = false,
    val enabledPoiCategories: Set<PoiCategory> = PoiCategory.entries.toSet(),
    val statusBanner: String? = null
)

data class PassengerUiData(
    val taxisInRadius: List<ActiveTaxi> = emptyList(),
    val filteredTaxis: List<ActiveTaxi> = emptyList(),
    val availableRoutes: List<String> = emptyList(),
    val firebaseStopsInRadius: List<MapPoi> = emptyList(),
    val visiblePois: List<MapPoi> = emptyList(),
    val selectedTaxi: ActiveTaxi? = null,
    val selectedPoi: MapPoi? = null,
    val filterState: PassengerFilterState = PassengerFilterState()
)

class PassengerViewModel(
    private val repository: TaxiDataSource,
    private val locationTracker: LocationSource,
    private val osmPoiRepository: OsmPoiDataSource = OsmPoiRepository()
) : ViewModel() {

    private val _filterState = MutableStateFlow(
        PassengerFilterState(
            hasLocationPermission = locationTracker.hasLocationPermission(),
            isLocatingGps = locationTracker.hasLocationPermission()
        )
    )
    val filterState: StateFlow<PassengerFilterState> = _filterState.asStateFlow()

    private val _osmPois = MutableStateFlow<List<MapPoi>>(emptyList())
    private var gpsStreamJob: Job? = null
    private var poiFetchJob: Job? = null
    private var lastPoiCenterLat: Double? = null
    private var lastPoiCenterLng: Double? = null
    private var lastPoiRadiusKm: Int = 0

    val uiState: StateFlow<UiState<PassengerUiData>> = combine(
        repository.observeActiveTaxis(),
        repository.observeTaxiStops(),
        _osmPois,
        _filterState
    ) { allTaxis, rawStops, osmPois, filter ->
        val center = filter.passengerLocation
        val radiusKm = filter.selectedRadius.km

        // Strict geographic radius filter anchored on passenger's real GPS location
        val taxisInRadius = if (center != null) {
            allTaxis.filter { taxi ->
                taxi.hasGpsFix && GeoUtils.isWithinRadiusKm(
                    centerLat = center.latitude,
                    centerLng = center.longitude,
                    targetLat = taxi.latitude,
                    targetLng = taxi.longitude,
                    radiusKm = radiusKm
                )
            }
        } else {
            emptyList()
        }

        val query = filter.searchQuery.trim().lowercase()
        val filteredTaxis = taxisInRadius.filter { taxi ->
            val matchesRoute = filter.selectedRoute == null ||
                taxi.route.equals(filter.selectedRoute, ignoreCase = true)
            val matchesSearch = query.isEmpty() ||
                taxi.route.lowercase().contains(query) ||
                taxi.vehicleModel.lowercase().contains(query) ||
                taxi.driverName.lowercase().contains(query) ||
                taxi.licensePlate.lowercase().contains(query)
            matchesRoute && matchesSearch
        }

        val firebaseStops = rawStops
            .filter { stop ->
                center != null && GeoUtils.isWithinRadiusKm(
                    centerLat = center.latitude,
                    centerLng = center.longitude,
                    targetLat = stop.latitude,
                    targetLng = stop.longitude,
                    radiusKm = radiusKm
                )
            }
            .map { stop -> stop.toMapPoi() }

        val osmFiltered = osmPois.filter { poi ->
            center != null &&
                GeoUtils.isWithinRadiusKm(
                    centerLat = center.latitude,
                    centerLng = center.longitude,
                    targetLat = poi.latitude,
                    targetLng = poi.longitude,
                    radiusKm = radiusKm
                )
        }

        val allPois = (firebaseStops + osmFiltered).filter { poi ->
            poi.category in filter.enabledPoiCategories
        }

        val routes = taxisInRadius.map { it.route }.filter { it.isNotBlank() }.distinct().sorted()
        // If a selected taxi moves outside the chosen radius, it automatically disappears
        val selectedTaxi = filteredTaxis.firstOrNull { it.driverId == filter.selectedTaxiId }
        val selectedPoi = allPois.firstOrNull { it.id == filter.selectedPoiId }

        UiState.Success(
            PassengerUiData(
                taxisInRadius = taxisInRadius,
                filteredTaxis = filteredTaxis,
                availableRoutes = routes,
                firebaseStopsInRadius = firebaseStops,
                visiblePois = allPois,
                selectedTaxi = selectedTaxi,
                selectedPoi = selectedPoi,
                filterState = filter
            )
        ) as UiState<PassengerUiData>
    }.catch { error ->
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val rootError = firestoreError ?: error
        Log.w(TAG, "Error observing passenger map data", rootError)
        emit(UiState.Error(rootError.message ?: "Erro ao sincronizar dados do mapa."))
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = UiState.Loading
    )

    init {
        if (locationTracker.hasLocationPermission()) {
            startPassengerLocationTracking()
        }
    }

    fun onPermissionResult(granted: Boolean) {
        val hasPerm = granted || locationTracker.hasLocationPermission()
        _filterState.update {
            it.copy(
                hasLocationPermission = hasPerm,
                isLocatingGps = hasPerm && it.passengerLocation == null
            )
        }
        if (hasPerm) {
            startPassengerLocationTracking()
        }
    }

    fun startPassengerLocationTracking() {
        if (!locationTracker.hasLocationPermission()) return
        if (gpsStreamJob?.isActive == true) return

        _filterState.update { it.copy(isLocatingGps = it.passengerLocation == null) }

        gpsStreamJob = viewModelScope.launch {
            // Warm immediate fix
            locationTracker.getCurrentLocation()?.let { initial ->
                handlePassengerLocation(initial)
            }
            // Continuous updates while passenger uses the map
            locationTracker.observeLocationUpdates(intervalMillis = 8000L)
                .catch { err ->
                    Log.w(TAG, "Passenger GPS stream stopped: ${err.message}")
                    _filterState.update { it.copy(isLocatingGps = false) }
                }
                .collect { loc ->
                    handlePassengerLocation(loc)
                }
        }
    }

    fun refreshPassengerLocation() {
        if (!locationTracker.hasLocationPermission()) return
        viewModelScope.launch {
            _filterState.update { it.copy(isLocatingGps = true) }
            val location = locationTracker.getCurrentLocation()
            if (location != null) {
                handlePassengerLocation(location)
            } else {
                _filterState.update { it.copy(isLocatingGps = false) }
            }
        }
    }

    private fun handlePassengerLocation(location: Location) {
        val previous = _filterState.value.passengerLocation
        _filterState.update {
            it.copy(
                passengerLocation = location,
                isLocatingGps = false
            )
        }
        val movedKm = if (previous == null) Double.MAX_VALUE else {
            GeoUtils.haversineDistanceKm(
                previous.latitude,
                previous.longitude,
                location.latitude,
                location.longitude
            )
        }
        if (previous == null || movedKm >= 0.5) {
            loadPoisForCurrentArea(location.latitude, location.longitude, _filterState.value.selectedRadius.km)
        }
    }

    fun selectRadius(radius: MapRadiusKm) {
        val current = _filterState.value
        _filterState.update {
            it.copy(
                selectedRadius = radius,
                showExpandAreaMenu = false
            )
        }
        val loc = current.passengerLocation ?: return
        // Only query Overpass if expanding beyond cached radius or moved significantly
        val movedKm = if (lastPoiCenterLat != null && lastPoiCenterLng != null) {
            GeoUtils.haversineDistanceKm(lastPoiCenterLat!!, lastPoiCenterLng!!, loc.latitude, loc.longitude)
        } else Double.MAX_VALUE

        if (radius.km > lastPoiRadiusKm || movedKm >= 0.8) {
            loadPoisForCurrentArea(loc.latitude, loc.longitude, radius.km)
        }
    }

    fun toggleExpandAreaMenu(show: Boolean? = null) {
        _filterState.update {
            it.copy(showExpandAreaMenu = show ?: !it.showExpandAreaMenu)
        }
    }

    fun togglePoiCategory(category: PoiCategory) {
        _filterState.update { current ->
            val updated = if (category in current.enabledPoiCategories) {
                current.enabledPoiCategories - category
            } else {
                current.enabledPoiCategories + category
            }
            current.copy(enabledPoiCategories = updated)
        }
    }

    private fun loadPoisForCurrentArea(lat: Double, lng: Double, radiusKm: Int) {
        poiFetchJob?.cancel()
        poiFetchJob = viewModelScope.launch {
            _filterState.update { it.copy(isLoadingPois = true) }
            val result = osmPoiRepository.fetchPoisWithinRadius(lat, lng, radiusKm)
            result.fold(
                onSuccess = { pois ->
                    lastPoiCenterLat = lat
                    lastPoiCenterLng = lng
                    lastPoiRadiusKm = maxOf(lastPoiRadiusKm, radiusKm)
                    _osmPois.value = pois
                    _filterState.update { it.copy(isLoadingPois = false, statusBanner = null) }
                },
                onFailure = { err ->
                    Log.w(TAG, "OSM POI fetch error: ${err.message}")
                    _filterState.update {
                        it.copy(
                            isLoadingPois = false,
                            statusBanner = "Referências OSM indisponíveis de momento; a mostrar táxis e paragens Firebase."
                        )
                    }
                }
            )
        }
    }

    fun registerTaxiStop(
        name: String,
        routeHint: String,
        stopType: TaxiStopType,
        latitude: Double,
        longitude: Double,
        onResult: (Result<Unit>) -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.createTaxiStop(
                name = name,
                routeHint = routeHint,
                stopType = stopType,
                latitude = latitude,
                longitude = longitude
            )
            result.fold(
                onSuccess = {
                    _filterState.update {
                        it.copy(statusBanner = "Paragem \"${name.trim()}\" registada no Rota Táxi.")
                    }
                },
                onFailure = { err ->
                    _filterState.update {
                        it.copy(statusBanner = err.message ?: "Não foi possível guardar a paragem.")
                    }
                }
            )
            onResult(result)
        }
    }

    fun selectRouteFilter(route: String?) {
        _filterState.update { it.copy(selectedRoute = route) }
    }

    fun updateSearchQuery(query: String) {
        _filterState.update { it.copy(searchQuery = query) }
    }

    fun selectTaxi(driverId: String?) {
        _filterState.update {
            it.copy(
                selectedTaxiId = driverId,
                selectedPoiId = null,
                showListSheet = false
            )
        }
    }

    fun selectPoi(poiId: String?) {
        _filterState.update {
            it.copy(
                selectedPoiId = poiId,
                selectedTaxiId = null
            )
        }
    }

    fun toggleListSheet(show: Boolean) {
        _filterState.update { it.copy(showListSheet = show) }
    }

    fun clearStatusBanner() {
        _filterState.update { it.copy(statusBanner = null) }
    }

    fun distanceInMetersTo(lat: Double, lng: Double): Double? {
        val myLoc = _filterState.value.passengerLocation ?: return null
        return GeoUtils.haversineDistanceMeters(myLoc.latitude, myLoc.longitude, lat, lng)
    }

    private fun TaxiStop.toMapPoi(): MapPoi = MapPoi(
        id = "fb_${id.ifBlank { "${latitude}_${longitude}" }}",
        name = name,
        category = PoiCategory.TAXI_STOP,
        latitude = latitude,
        longitude = longitude,
        subtitle = routeHint.ifBlank { parsedType.labelPt },
        isRotaTaxiRegistered = true
    )

    override fun onCleared() {
        super.onCleared()
        gpsStreamJob?.cancel()
        poiFetchJob?.cancel()
    }

    private companion object {
        const val TAG = "PassengerViewModel"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
