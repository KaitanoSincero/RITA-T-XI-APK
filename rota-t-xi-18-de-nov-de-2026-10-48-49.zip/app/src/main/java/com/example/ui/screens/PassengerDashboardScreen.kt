package com.example.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.FormatListBulleted
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AddLocationAlt
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.EventSeat
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.LocalTaxi
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.model.ActiveTaxi
import com.example.model.MapPoi
import com.example.model.PoiCategory
import com.example.model.TaxiStopType
import com.example.ui.components.MapFocusTarget
import com.example.ui.components.RotaTaxiLeafletMap
import com.example.ui.passenger.PassengerUiData
import com.example.ui.passenger.PassengerViewModel
import com.example.ui.state.UiState
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.EmeraldActive
import com.example.ui.theme.HudBankPurple
import com.example.ui.theme.HudBeaconYellow
import com.example.ui.theme.HudBorderSubtle
import com.example.ui.theme.HudDarkBackground
import com.example.ui.theme.HudDarkElevated
import com.example.ui.theme.HudDarkSurface
import com.example.ui.theme.HudEmerald
import com.example.ui.theme.HudHospitalRed
import com.example.ui.theme.HudSchoolBlue
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.TaxiGold
import com.example.util.GeoUtils
import com.example.util.MapRadiusKm
import java.util.Locale
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PassengerDashboardScreen(
    viewModel: PassengerViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val filterState by viewModel.filterState.collectAsStateWithLifecycle()

    var recenterTrigger by remember { mutableLongStateOf(0L) }
    var radiusZoomTrigger by remember { mutableLongStateOf(0L) }
    var focusTarget by remember { mutableStateOf<MapFocusTarget?>(null) }

    var pendingStopCoords by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var showRegisterStopDialog by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        viewModel.onPermissionResult(granted)
    }

    LaunchedEffect(Unit) {
        if (!filterState.hasLocationPermission) {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        } else {
            viewModel.startPassengerLocationTracking()
        }
    }

    val successData = (uiState as? UiState.Success<PassengerUiData>)?.data
    val filteredTaxis = successData?.filteredTaxis.orEmpty()
    val visiblePois = successData?.visiblePois.orEmpty()
    val selectedTaxi = successData?.selectedTaxi
    val selectedPoi = successData?.selectedPoi

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(HudDarkBackground)
    ) {
        // OpenStreetMap + Leaflet Interactive Urban Mobility Map
        RotaTaxiLeafletMap(
            modifier = Modifier.fillMaxSize(),
            passengerLocation = filterState.passengerLocation,
            selectedRadius = filterState.selectedRadius,
            taxis = filteredTaxis,
            pois = visiblePois,
            selectedTaxiId = selectedTaxi?.driverId,
            selectedPoiId = selectedPoi?.id,
            recenterTrigger = recenterTrigger,
            radiusZoomTrigger = radiusZoomTrigger,
            focusTarget = focusTarget,
            onTaxiSelected = { driverId -> viewModel.selectTaxi(driverId) },
            onPoiSelected = { poiId -> viewModel.selectPoi(poiId) },
            onMapCleared = {
                viewModel.selectTaxi(null)
                viewModel.selectPoi(null)
                viewModel.toggleExpandAreaMenu(false)
            },
            onMapLongPressed = { lat, lng ->
                pendingStopCoords = lat to lng
                showRegisterStopDialog = true
            }
        )

        // Top Floating Dark Mobility HUD Bar & Route Filter
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .widthIn(max = 680.dp)
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                color = HudDarkSurface,
                contentColor = Color.White,
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, HudBorderSubtle),
                shadowElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("btn_passenger_back")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.cd_back),
                            tint = Color.White
                        )
                    }

                    OutlinedTextField(
                        value = filterState.searchQuery,
                        onValueChange = viewModel::updateSearchQuery,
                        placeholder = {
                            Text(
                                text = "Pesquisar rota ou táxi…",
                                color = Color.White.copy(alpha = 0.55f)
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.Search,
                                contentDescription = null,
                                tint = TaxiGold
                            )
                        },
                        trailingIcon = {
                            if (filterState.searchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                                    Icon(
                                        imageVector = Icons.Filled.Close,
                                        contentDescription = "Limpar pesquisa",
                                        tint = Color.White.copy(alpha = 0.75f)
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            cursorColor = TaxiGold,
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent
                        ),
                        modifier = Modifier.weight(1f)
                    )

                    Surface(
                        color = if (filteredTaxis.isNotEmpty()) HudEmerald.copy(alpha = 0.2f)
                        else Color.White.copy(alpha = 0.1f),
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(
                            1.dp,
                            if (filteredTaxis.isNotEmpty()) HudEmerald.copy(alpha = 0.5f) else HudBorderSubtle
                        ),
                        modifier = Modifier.padding(end = 6.dp)
                    ) {
                        Text(
                            text = "${filteredTaxis.size} • ${filterState.selectedRadius.km}km",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (filteredTaxis.isNotEmpty()) HudEmerald else Color.White,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            // Route Filter Chips (only routes inside active radius)
            val routes = successData?.availableRoutes.orEmpty()
            if (routes.isNotEmpty()) {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(horizontal = 2.dp)
                ) {
                    item {
                        FilterChip(
                            selected = filterState.selectedRoute == null,
                            onClick = { viewModel.selectRouteFilter(null) },
                            label = { Text(stringResource(R.string.all_routes)) },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = HudDarkSurface,
                                labelColor = Color.White.copy(alpha = 0.85f),
                                selectedContainerColor = TaxiGold,
                                selectedLabelColor = Color(0xFF1F1300)
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = filterState.selectedRoute == null,
                                borderColor = HudBorderSubtle
                            )
                        )
                    }
                    items(routes) { route ->
                        val isSelected = filterState.selectedRoute == route
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.selectRouteFilter(if (isSelected) null else route) },
                            label = { Text(route) },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = HudDarkSurface,
                                labelColor = Color.White.copy(alpha = 0.85f),
                                selectedContainerColor = TaxiGold,
                                selectedLabelColor = Color(0xFF1F1300)
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = HudBorderSubtle
                            )
                        )
                    }
                }
            }

            // GPS Acquisition / Permission Banner
            if (!filterState.hasLocationPermission) {
                Surface(
                    color = HudDarkElevated,
                    contentColor = Color.White,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, TaxiGold.copy(alpha = 0.55f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.GpsFixed,
                                contentDescription = null,
                                tint = TaxiGold,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = stringResource(R.string.gps_enable_prompt),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                permissionLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.ACCESS_FINE_LOCATION,
                                        Manifest.permission.ACCESS_COARSE_LOCATION
                                    )
                                )
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = TaxiGold,
                                contentColor = Color(0xFF1F1300)
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Ativar GPS", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            } else if (filterState.isLocatingGps && filterState.passengerLocation == null) {
                Surface(
                    color = HudDarkElevated,
                    contentColor = Color.White,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, HudBorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = HudBeaconYellow,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = stringResource(R.string.gps_locating_passenger),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }

            if (filterState.statusBanner != null) {
                Surface(
                    color = HudDarkElevated,
                    contentColor = Color.White,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, HudBorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = filterState.statusBanner ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { viewModel.clearStatusBanner() },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "Fechar aviso",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            if (uiState is UiState.Error) {
                Surface(
                    color = CrimsonAlert.copy(alpha = 0.92f),
                    contentColor = Color.White,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = (uiState as UiState.Error).message,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }

        // Left Vertical Floating POI Layer & Stop Registration Stack (Reference Image Style)
        Column(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            PoiLayerToggleChip(
                icon = Icons.Filled.DirectionsBus,
                active = PoiCategory.TAXI_STOP in filterState.enabledPoiCategories,
                activeColor = TaxiGold,
                contentDesc = "Mostrar paragens de táxi",
                onClick = { viewModel.togglePoiCategory(PoiCategory.TAXI_STOP) }
            )
            PoiLayerToggleChip(
                icon = Icons.Filled.LocalHospital,
                active = PoiCategory.HOSPITAL in filterState.enabledPoiCategories,
                activeColor = HudHospitalRed,
                contentDesc = "Mostrar hospitais",
                onClick = { viewModel.togglePoiCategory(PoiCategory.HOSPITAL) }
            )
            PoiLayerToggleChip(
                icon = Icons.Filled.School,
                active = PoiCategory.SCHOOL in filterState.enabledPoiCategories,
                activeColor = HudSchoolBlue,
                contentDesc = "Mostrar escolas",
                onClick = { viewModel.togglePoiCategory(PoiCategory.SCHOOL) }
            )
            PoiLayerToggleChip(
                icon = Icons.Filled.Storefront,
                active = PoiCategory.MARKET in filterState.enabledPoiCategories,
                activeColor = HudEmerald,
                contentDesc = "Mostrar mercados",
                onClick = { viewModel.togglePoiCategory(PoiCategory.MARKET) }
            )
            PoiLayerToggleChip(
                icon = Icons.Filled.AccountBalance,
                active = PoiCategory.BANK in filterState.enabledPoiCategories,
                activeColor = HudBankPurple,
                contentDesc = "Mostrar bancos",
                onClick = { viewModel.togglePoiCategory(PoiCategory.BANK) }
            )
            PoiLayerToggleChip(
                icon = Icons.Filled.Apartment,
                active = PoiCategory.INSTITUTION in filterState.enabledPoiCategories,
                activeColor = Color(0xFF94A3B8),
                contentDesc = "Mostrar instituições",
                onClick = { viewModel.togglePoiCategory(PoiCategory.INSTITUTION) }
            )

            // Register a new Rota Táxi stop at passenger GPS
            SmallFloatingActionButton(
                onClick = {
                    val loc = filterState.passengerLocation
                    if (loc != null) {
                        pendingStopCoords = loc.latitude to loc.longitude
                        showRegisterStopDialog = true
                    } else {
                        permissionLauncher.launch(
                            arrayOf(
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                            )
                        )
                    }
                },
                containerColor = NavyDeep,
                contentColor = TaxiGold,
                shape = CircleShape,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("btn_register_stop")
            ) {
                Icon(
                    imageVector = Icons.Filled.AddLocationAlt,
                    contentDescription = stringResource(R.string.register_stop),
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        // Right-side Map Controls: EXPANDIR ÁREA (5/10/15/20 KM) + Recenter on Passenger
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(
                    end = 12.dp,
                    bottom = if (selectedTaxi != null || selectedPoi != null) 256.dp else 104.dp
                ),
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            AnimatedVisibility(
                visible = filterState.showExpandAreaMenu,
                enter = fadeIn() + slideInVertically { it / 2 },
                exit = fadeOut()
            ) {
                Surface(
                    color = HudDarkElevated,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, HudBorderSubtle),
                    shadowElevation = 8.dp
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(
                            text = "Raio a partir do seu GPS",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.7f),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            MapRadiusKm.entries.forEach { radiusOption ->
                                val isCurrent = filterState.selectedRadius == radiusOption
                                Surface(
                                    onClick = {
                                        viewModel.selectRadius(radiusOption)
                                        radiusZoomTrigger++
                                    },
                                    color = if (isCurrent) HudEmerald else HudDarkSurface,
                                    contentColor = if (isCurrent) Color(0xFF022C22) else Color.White,
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isCurrent) HudEmerald else HudBorderSubtle
                                    ),
                                    modifier = Modifier.testTag("radius_${radiusOption.km}km")
                                ) {
                                    Text(
                                        text = "${radiusOption.km} KM",
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.ExtraBold,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Visible EXPANDIR ÁREA Button
                Surface(
                    onClick = { viewModel.toggleExpandAreaMenu() },
                    color = HudDarkElevated,
                    contentColor = Color.White,
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, TaxiGold.copy(alpha = 0.75f)),
                    shadowElevation = 6.dp,
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("btn_expand_area")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Radar,
                            contentDescription = null,
                            tint = TaxiGold,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${stringResource(R.string.expand_area)} (${filterState.selectedRadius.km} KM)",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Return to Current GPS Location Button (preserves selected radius)
                Surface(
                    onClick = {
                        if (filterState.hasLocationPermission) {
                            viewModel.refreshPassengerLocation()
                            recenterTrigger++
                        } else {
                            permissionLauncher.launch(
                                arrayOf(
                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION
                                )
                            )
                        }
                    },
                    color = HudDarkElevated,
                    contentColor = HudBeaconYellow,
                    shape = CircleShape,
                    border = BorderStroke(1.dp, HudBorderSubtle),
                    shadowElevation = 6.dp,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("btn_center_location")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Filled.MyLocation,
                            contentDescription = stringResource(R.string.cd_center_location)
                        )
                    }
                }
            }
        }

        // Bottom HUD Capsule OR Selected Taxi/POI Card
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .widthIn(max = 680.dp)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 12.dp, vertical = 14.dp)
        ) {
            if (selectedTaxi != null) {
                SelectedTaxiDetailCard(
                    taxi = selectedTaxi,
                    distanceMeters = viewModel.distanceInMetersTo(selectedTaxi.latitude, selectedTaxi.longitude),
                    onFocusMap = {
                        focusTarget = MapFocusTarget(selectedTaxi.latitude, selectedTaxi.longitude, 16)
                    },
                    onClose = { viewModel.selectTaxi(null) }
                )
            } else if (selectedPoi != null) {
                SelectedPoiDetailCard(
                    poi = selectedPoi,
                    distanceMeters = viewModel.distanceInMetersTo(selectedPoi.latitude, selectedPoi.longitude),
                    onFocusMap = {
                        focusTarget = MapFocusTarget(selectedPoi.latitude, selectedPoi.longitude, 16)
                    },
                    onClose = { viewModel.selectPoi(null) }
                )
            } else {
                // Reference-inspired Bottom Dark Mobility Summary Pill
                Surface(
                    color = HudDarkSurface,
                    contentColor = Color.White,
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, HudBorderSubtle),
                    shadowElevation = 8.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            if (uiState is UiState.Loading || filterState.isLoadingPois) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = TaxiGold,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Filled.LocalTaxi,
                                    contentDescription = null,
                                    tint = TaxiGold
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = when {
                                        filterState.passengerLocation == null -> "A aguardar GPS para filtrar ${filterState.selectedRadius.km} km"
                                        filteredTaxis.isEmpty() -> "Sem táxis num raio de ${filterState.selectedRadius.km} km"
                                        filteredTaxis.size == 1 -> "1 táxi num raio de ${filterState.selectedRadius.km} km"
                                        else -> "${filteredTaxis.size} táxis num raio de ${filterState.selectedRadius.km} km"
                                    },
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${visiblePois.size} paragens e referências carregadas",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White.copy(alpha = 0.72f)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Button(
                            onClick = { viewModel.toggleListSheet(true) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = TaxiGold,
                                contentColor = Color(0xFF1F1300)
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.testTag("btn_toggle_taxi_list")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.FormatListBulleted,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Lista")
                        }
                    }
                }
            }
        }

        // Bottom Sheet List of Active Taxis Within Selected Radius
        if (filterState.showListSheet) {
            ModalBottomSheet(
                onDismissRequest = { viewModel.toggleListSheet(false) },
                sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
                containerColor = HudDarkElevated,
                contentColor = Color.White
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .navigationBarsPadding()
                ) {
                    Text(
                        text = "Táxis num raio de ${filterState.selectedRadius.km} km",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Atualizados em tempo real pelo Firebase",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    if (filteredTaxis.isEmpty()) {
                        Surface(
                            color = HudDarkSurface,
                            shape = MaterialTheme.shapes.medium,
                            border = BorderStroke(1.dp, HudBorderSubtle),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 24.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.LocalTaxi,
                                    contentDescription = null,
                                    tint = TaxiGold,
                                    modifier = Modifier.size(36.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = stringResource(R.string.active_taxis_empty),
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = "Experimente tocar em EXPANDIR ÁREA para 10, 15 ou 20 km.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White.copy(alpha = 0.7f)
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(bottom = 24.dp)
                        ) {
                            items(filteredTaxis, key = { it.driverId }) { taxi ->
                                ActiveTaxiListItem(
                                    taxi = taxi,
                                    distanceMeters = viewModel.distanceInMetersTo(taxi.latitude, taxi.longitude),
                                    onClick = {
                                        viewModel.selectTaxi(taxi.driverId)
                                        focusTarget = MapFocusTarget(taxi.latitude, taxi.longitude, 16)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Dialog to Register a New Rota Táxi Stop in Firebase
        if (showRegisterStopDialog && pendingStopCoords != null) {
            RegisterStopDialog(
                latitude = pendingStopCoords!!.first,
                longitude = pendingStopCoords!!.second,
                onDismiss = { showRegisterStopDialog = false },
                onConfirm = { name, routeHint, stopType ->
                    viewModel.registerTaxiStop(
                        name = name,
                        routeHint = routeHint,
                        stopType = stopType,
                        latitude = pendingStopCoords!!.first,
                        longitude = pendingStopCoords!!.second
                    ) { result ->
                        showRegisterStopDialog = false
                        if (result.isFailure) {
                            // Error logged by TaxiRepository; keep UI crash-safe
                        }
                    }
                }
            )
        }
    }
}

@Composable
private fun PoiLayerToggleChip(
    icon: ImageVector,
    active: Boolean,
    activeColor: Color,
    contentDesc: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        color = if (active) HudDarkElevated else HudDarkBackground.copy(alpha = 0.65f),
        contentColor = if (active) activeColor else Color.White.copy(alpha = 0.4f),
        shape = CircleShape,
        border = BorderStroke(1.5.dp, if (active) activeColor.copy(alpha = 0.85f) else HudBorderSubtle),
        shadowElevation = 4.dp,
        modifier = Modifier.size(48.dp)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = contentDesc,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun SelectedTaxiDetailCard(
    taxi: ActiveTaxi,
    distanceMeters: Double?,
    onFocusMap: () -> Unit,
    onClose: () -> Unit
) {
    val maxSeats = taxi.maxSeats.coerceAtLeast(1L).toFloat()
    val occupiedRatio = ((taxi.maxSeats - taxi.availableSeats).coerceAtLeast(0L) / maxSeats).coerceIn(0f, 1f)

    Card(
        colors = CardDefaults.cardColors(
            containerColor = HudDarkElevated,
            contentColor = Color.White
        ),
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, TaxiGold.copy(alpha = 0.6f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("selected_taxi_card")
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Surface(
                        color = NavyDeep,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, TaxiGold),
                        modifier = Modifier.size(42.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Filled.Route,
                                contentDescription = null,
                                tint = TaxiGold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = taxi.route,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(HudEmerald)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Posição GPS ao vivo",
                                style = MaterialTheme.typography.labelSmall,
                                color = HudEmerald
                            )
                        }
                    }
                }

                IconButton(onClick = onClose) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Fechar detalhes",
                        tint = Color.White.copy(alpha = 0.75f)
                    )
                }
            }

            HorizontalDivider(color = HudBorderSubtle)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.EventSeat,
                        contentDescription = null,
                        tint = TaxiGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (taxi.availableSeats > 0) {
                            "${taxi.availableSeats} de ${taxi.maxSeats} lugares livres"
                        } else {
                            "Lotado (0/${taxi.maxSeats} lugares)"
                        },
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (taxi.availableSeats > 0) HudEmerald else CrimsonAlert
                    )
                }

                if (distanceMeters != null) {
                    Surface(
                        color = TaxiGold.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(1.dp, TaxiGold.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = "A ${GeoUtils.formatDistancePt(distanceMeters)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = TaxiGold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            LinearProgressIndicator(
                progress = { occupiedRatio },
                color = if (taxi.availableSeats > 0) HudEmerald else CrimsonAlert,
                trackColor = Color.White.copy(alpha = 0.14f),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Filled.DirectionsCar,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.7f),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "${taxi.vehicleModel} • ${taxi.vehicleColor} (${taxi.licensePlate})",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.9f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Person,
                        contentDescription = null,
                        tint = Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = taxi.driverName.ifBlank { "Motorista ROTA TÁXI" },
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Speed,
                        contentDescription = null,
                        tint = Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${taxi.speedKmh.roundToInt()} km/h",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                }
            }

            Button(
                onClick = onFocusMap,
                colors = ButtonDefaults.buttonColors(
                    containerColor = TaxiGold,
                    contentColor = Color(0xFF1F1300)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Focar táxi no mapa", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun SelectedPoiDetailCard(
    poi: MapPoi,
    distanceMeters: Double?,
    onFocusMap: () -> Unit,
    onClose: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = HudDarkElevated,
            contentColor = Color.White
        ),
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, HudBorderSubtle),
        elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (poi.isRotaTaxiRegistered) "Paragem Oficial Rota Táxi" else poi.category.labelPt,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (poi.isRotaTaxiRegistered) TaxiGold else HudEmerald
                    )
                    Text(
                        text = poi.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = onClose) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Fechar referência",
                        tint = Color.White.copy(alpha = 0.75f)
                    )
                }
            }

            if (poi.subtitle.isNotBlank()) {
                Text(
                    text = poi.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.8f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (poi.isRotaTaxiRegistered) "Sincronizado com Firebase" else "Dados OpenStreetMap",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.65f)
                )
                if (distanceMeters != null) {
                    Text(
                        text = "A ${GeoUtils.formatDistancePt(distanceMeters)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = TaxiGold
                    )
                }
            }

            Button(
                onClick = onFocusMap,
                colors = ButtonDefaults.buttonColors(
                    containerColor = NavyDeep,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Centrar ponto no mapa")
            }
        }
    }
}

@Composable
private fun ActiveTaxiListItem(
    taxi: ActiveTaxi,
    distanceMeters: Double?,
    onClick: () -> Unit
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = HudDarkSurface,
        border = BorderStroke(1.dp, HudBorderSubtle),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = NavyDeep,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, TaxiGold),
                modifier = Modifier.size(44.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Filled.LocalTaxi,
                        contentDescription = null,
                        tint = TaxiGold
                    )
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = taxi.route,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "${taxi.vehicleModel} • ${taxi.vehicleColor} • ${taxi.licensePlate}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.72f)
                )
                if (distanceMeters != null) {
                    Text(
                        text = "A ${GeoUtils.formatDistancePt(distanceMeters)} de si",
                        style = MaterialTheme.typography.labelSmall,
                        color = HudEmerald
                    )
                }
            }
            Surface(
                color = if (taxi.availableSeats > 0) EmeraldActive.copy(alpha = 0.2f)
                else CrimsonAlert.copy(alpha = 0.2f),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(
                    1.dp,
                    if (taxi.availableSeats > 0) EmeraldActive else CrimsonAlert
                )
            ) {
                Text(
                    text = "${taxi.availableSeats} lug.",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (taxi.availableSeats > 0) HudEmerald else CrimsonAlert,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
private fun RegisterStopDialog(
    latitude: Double,
    longitude: Double,
    onDismiss: () -> Unit,
    onConfirm: (name: String, routeHint: String, stopType: TaxiStopType) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var routeHint by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(TaxiStopType.TAXI_STOP) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Registar Paragem no Rota Táxi") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Guardar ponto de táxi em tempo real no Firebase (${String.format(Locale.US, "%.4f, %.4f", latitude, longitude)}).",
                    style = MaterialTheme.typography.bodySmall
                )
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nome da paragem") },
                    placeholder = { Text("Ex: Paragem da Mutamba") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = routeHint,
                    onValueChange = { routeHint = it },
                    label = { Text("Rota principal (opcional)") },
                    placeholder = { Text("Ex: Benfica → Mutamba") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TaxiStopType.entries.forEach { type ->
                        FilterChip(
                            selected = selectedType == type,
                            onClick = { selectedType = type },
                            label = { Text(type.labelPt) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(name, routeHint, selectedType) },
                enabled = name.trim().length >= 2
            ) {
                Text("Guardar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}
