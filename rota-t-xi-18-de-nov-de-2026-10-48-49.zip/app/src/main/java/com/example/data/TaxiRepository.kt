package com.example.data

import android.content.Context
import android.location.Location
import com.example.R
import com.example.model.ActiveTaxi
import com.example.model.DriverProfile
import com.example.model.TaxiStatus
import com.example.model.TaxiStop
import com.example.model.TaxiStopType
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

interface TaxiDataSource {
    fun observeActiveTaxis(): Flow<List<ActiveTaxi>>
    fun observeTaxiStops(): Flow<List<TaxiStop>>
    suspend fun createTaxiStop(
        name: String,
        routeHint: String,
        stopType: TaxiStopType,
        latitude: Double,
        longitude: Double
    ): Result<Unit>
}

class TaxiRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) : TaxiDataSource {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("Utilizador deve autenticar-se com Google antes de aceder ao Firestore.")
    }

    fun observeDriverProfile(userId: String): Flow<DriverProfile?> =
        db.collection(COLLECTION_DRIVERS)
            .document(userId)
            .snapshots()
            .map { snapshot ->
                if (!snapshot.exists()) null
                else snapshot.toObject(
                    DriverProfile::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }

    suspend fun saveDriverProfile(
        userId: String,
        fullName: String,
        phone: String,
        vehicleModel: String,
        vehicleColor: String,
        licensePlate: String,
        maxSeats: Int,
        defaultRoute: String
    ): Result<Unit> {
        val docPath = "$COLLECTION_DRIVERS/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Sessão alterada; escrita recusada." }

            val cleanName = fullName.trim()
            val cleanPhone = phone.trim()
            val cleanModel = vehicleModel.trim()
            val cleanColor = vehicleColor.trim()
            val cleanPlate = licensePlate.trim().uppercase()
            val cleanRoute = defaultRoute.trim()

            require(cleanName.length in 2..80) { "Nome do motorista deve ter entre 2 e 80 caracteres." }
            require(cleanPhone.length in 6..25) { "Número de telefone deve ter entre 6 e 25 caracteres." }
            require(cleanModel.length in 2..60) { "Modelo do veículo deve ter entre 2 e 60 caracteres." }
            require(cleanColor.length in 2..40) { "Cor do veículo deve ter entre 2 e 40 caracteres." }
            require(cleanPlate.length in 3..20) { "Matrícula deve ter entre 3 e 20 caracteres." }
            require(maxSeats in 1..30) { "Lotação máxima deve estar entre 1 e 30 lugares." }
            require(cleanRoute.length in 3..100) { "Rota deve ter entre 3 e 100 caracteres." }

            val docRef = db.collection(COLLECTION_DRIVERS).document(userId)
            val exists = docRef.get().await().exists()

            if (exists) {
                docRef.update(
                    mapOf(
                        "fullName" to cleanName,
                        "phone" to cleanPhone,
                        "vehicleModel" to cleanModel,
                        "vehicleColor" to cleanColor,
                        "licensePlate" to cleanPlate,
                        "maxSeats" to maxSeats.toLong(),
                        "defaultRoute" to cleanRoute,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                docRef.set(
                    mapOf(
                        "userId" to uid,
                        "fullName" to cleanName,
                        "phone" to cleanPhone,
                        "vehicleModel" to cleanModel,
                        "vehicleColor" to cleanColor,
                        "licensePlate" to cleanPlate,
                        "maxSeats" to maxSeats.toLong(),
                        "defaultRoute" to cleanRoute,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    fun observeOwnTaxi(driverId: String): Flow<ActiveTaxi?> =
        db.collection(COLLECTION_ACTIVE_TAXIS)
            .document(driverId)
            .snapshots()
            .map { snapshot ->
                if (!snapshot.exists()) null
                else snapshot.toObject(
                    ActiveTaxi::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }

    override fun observeActiveTaxis(): Flow<List<ActiveTaxi>> =
        db.collection(COLLECTION_ACTIVE_TAXIS)
            .whereEqualTo("status", TaxiStatus.ACTIVE.wireValue)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    ActiveTaxi::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }

    override fun observeTaxiStops(): Flow<List<TaxiStop>> =
        db.collection(COLLECTION_TAXI_STOPS)
            .whereEqualTo("status", TaxiStatus.ACTIVE.wireValue)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    TaxiStop::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }

    override suspend fun createTaxiStop(
        name: String,
        routeHint: String,
        stopType: TaxiStopType,
        latitude: Double,
        longitude: Double
    ): Result<Unit> {
        var docPath = COLLECTION_TAXI_STOPS
        return try {
            val uid = requireUserId()
            val cleanName = name.trim()
            val cleanRouteHint = routeHint.trim().take(100)
            require(cleanName.length in 2..80) { "Nome da paragem deve ter entre 2 e 80 caracteres." }
            require(latitude in -90.0..90.0) { "Latitude inválida." }
            require(longitude in -180.0..180.0) { "Longitude inválida." }

            val docRef = db.collection(COLLECTION_TAXI_STOPS).document()
            docPath = docRef.path
            docRef.set(
                mapOf(
                    "createdBy" to uid,
                    "name" to cleanName,
                    "routeHint" to cleanRouteHint,
                    "stopType" to stopType.wireValue,
                    "status" to TaxiStatus.ACTIVE.wireValue,
                    "latitude" to latitude,
                    "longitude" to longitude,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun startOrUpdateTrip(
        driverId: String,
        driverName: String,
        vehicleModel: String,
        vehicleColor: String,
        licensePlate: String,
        route: String,
        availableSeats: Int,
        maxSeats: Int,
        initialLocation: Location?
    ): Result<Unit> {
        val docPath = "$COLLECTION_ACTIVE_TAXIS/$driverId"
        return try {
            val uid = requireUserId()
            check(uid == driverId) { "Sessão alterada; escrita recusada." }

            val cleanName = driverName.trim().take(60)
            val cleanModel = vehicleModel.trim()
            val cleanColor = vehicleColor.trim()
            val cleanPlate = licensePlate.trim().uppercase()
            val cleanRoute = route.trim()

            require(cleanName.length in 2..60) { "Nome do motorista inválido." }
            require(cleanModel.length in 2..60) { "Modelo do veículo inválido." }
            require(cleanColor.length in 2..40) { "Cor do veículo inválida." }
            require(cleanPlate.length in 3..20) { "Matrícula inválida." }
            require(cleanRoute.length in 3..100) { "Rota inválida." }
            require(maxSeats in 1..30) { "Lotação máxima inválida." }
            require(availableSeats in 0..maxSeats) { "Lugares disponíveis inválidos." }

            val hasFix = initialLocation != null
            val lat = initialLocation?.latitude?.coerceIn(-90.0, 90.0) ?: 0.0
            val lng = initialLocation?.longitude?.coerceIn(-180.0, 180.0) ?: 0.0
            val bearing = if (initialLocation != null && initialLocation.hasBearing()) {
                initialLocation.bearing.toDouble().coerceIn(0.0, 360.0)
            } else 0.0
            val speedKmh = if (initialLocation != null && initialLocation.hasSpeed()) {
                (initialLocation.speed * 3.6).coerceIn(0.0, 250.0)
            } else 0.0
            val accuracy = if (initialLocation != null && initialLocation.hasAccuracy()) {
                initialLocation.accuracy.toDouble().coerceIn(0.0, 5000.0)
            } else 0.0

            val docRef = db.collection(COLLECTION_ACTIVE_TAXIS).document(driverId)
            val exists = docRef.get().await().exists()

            if (exists) {
                docRef.update(
                    mapOf(
                        "driverName" to cleanName,
                        "vehicleModel" to cleanModel,
                        "vehicleColor" to cleanColor,
                        "licensePlate" to cleanPlate,
                        "route" to cleanRoute,
                        "availableSeats" to availableSeats.toLong(),
                        "maxSeats" to maxSeats.toLong(),
                        "status" to TaxiStatus.ACTIVE.wireValue,
                        "latitude" to lat,
                        "longitude" to lng,
                        "bearing" to bearing,
                        "speedKmh" to speedKmh,
                        "accuracyMeters" to accuracy,
                        "hasGpsFix" to hasFix,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                docRef.set(
                    mapOf(
                        "driverId" to uid,
                        "driverName" to cleanName,
                        "vehicleModel" to cleanModel,
                        "vehicleColor" to cleanColor,
                        "licensePlate" to cleanPlate,
                        "route" to cleanRoute,
                        "availableSeats" to availableSeats.toLong(),
                        "maxSeats" to maxSeats.toLong(),
                        "status" to TaxiStatus.ACTIVE.wireValue,
                        "latitude" to lat,
                        "longitude" to lng,
                        "bearing" to bearing,
                        "speedKmh" to speedKmh,
                        "accuracyMeters" to accuracy,
                        "hasGpsFix" to hasFix,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateTaxiLocation(driverId: String, location: Location): Result<Unit> {
        val docPath = "$COLLECTION_ACTIVE_TAXIS/$driverId"
        return try {
            val uid = requireUserId()
            check(uid == driverId) { "Sessão alterada; atualização de GPS recusada." }

            val bearing = if (location.hasBearing()) {
                location.bearing.toDouble().coerceIn(0.0, 360.0)
            } else 0.0
            val speedKmh = if (location.hasSpeed()) {
                (location.speed * 3.6).coerceIn(0.0, 250.0)
            } else 0.0
            val accuracy = if (location.hasAccuracy()) {
                location.accuracy.toDouble().coerceIn(0.0, 5000.0)
            } else 0.0

            db.collection(COLLECTION_ACTIVE_TAXIS)
                .document(driverId)
                .update(
                    mapOf(
                        "latitude" to location.latitude.coerceIn(-90.0, 90.0),
                        "longitude" to location.longitude.coerceIn(-180.0, 180.0),
                        "bearing" to bearing,
                        "speedKmh" to speedKmh,
                        "accuracyMeters" to accuracy,
                        "hasGpsFix" to true,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateAvailableSeats(driverId: String, availableSeats: Int): Result<Unit> {
        val docPath = "$COLLECTION_ACTIVE_TAXIS/$driverId"
        return try {
            val uid = requireUserId()
            check(uid == driverId) { "Sessão alterada; atualização de lugares recusada." }
            require(availableSeats in 0..30) { "Lugares disponíveis inválidos." }

            db.collection(COLLECTION_ACTIVE_TAXIS)
                .document(driverId)
                .update(
                    mapOf(
                        "availableSeats" to availableSeats.toLong(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun endTrip(driverId: String): Result<Unit> {
        val docPath = "$COLLECTION_ACTIVE_TAXIS/$driverId"
        return try {
            val uid = requireUserId()
            check(uid == driverId) { "Sessão alterada; término de viagem recusado." }

            db.collection(COLLECTION_ACTIVE_TAXIS)
                .document(driverId)
                .update(
                    mapOf(
                        "status" to TaxiStatus.INACTIVE.wireValue,
                        "hasGpsFix" to false,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    companion object {
        const val COLLECTION_DRIVERS = "drivers"
        const val COLLECTION_ACTIVE_TAXIS = "active_taxis"
        const val COLLECTION_TAXI_STOPS = "taxi_stops"
    }
}
