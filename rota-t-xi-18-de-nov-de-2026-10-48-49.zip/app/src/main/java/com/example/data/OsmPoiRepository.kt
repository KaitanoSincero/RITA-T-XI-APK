package com.example.data

import android.util.Log
import com.example.model.MapPoi
import com.example.model.PoiCategory
import com.example.util.GeoUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

interface OsmPoiDataSource {
    suspend fun fetchPoisWithinRadius(
        centerLat: Double,
        centerLng: Double,
        radiusKm: Int
    ): Result<List<MapPoi>>
}

class OsmPoiRepository(
    private val client: OkHttpClient = defaultClient()
) : OsmPoiDataSource {
    private val cacheMutex = Mutex()
    private var cachedCenterLat: Double? = null
    private var cachedCenterLng: Double? = null
    private var cachedMaxRadiusKm: Int = 0
    private var cachedPois: List<MapPoi> = emptyList()
    private var lastFetchEpochMs: Long = 0L

    override suspend fun fetchPoisWithinRadius(
        centerLat: Double,
        centerLng: Double,
        radiusKm: Int
    ): Result<List<MapPoi>> = withContext(Dispatchers.IO) {
        val clampedRadiusKm = radiusKm.coerceIn(5, 20)
        val now = System.currentTimeMillis()

        val cacheHit = cacheMutex.withLock {
            val prevLat = cachedCenterLat
            val prevLng = cachedCenterLng
            if (prevLat != null && prevLng != null) {
                val movedKm = GeoUtils.haversineDistanceKm(prevLat, prevLng, centerLat, centerLng)
                val cacheValid = movedKm <= CACHE_REUSE_DRIFT_KM &&
                    clampedRadiusKm <= cachedMaxRadiusKm &&
                    (now - lastFetchEpochMs) <= CACHE_TTL_MS
                if (cacheValid) {
                    cachedPois.filter { poi ->
                        GeoUtils.isWithinRadiusKm(
                            centerLat,
                            centerLng,
                            poi.latitude,
                            poi.longitude,
                            clampedRadiusKm
                        )
                    }
                } else null
            } else null
        }

        if (cacheHit != null) {
            return@withContext Result.success(cacheHit)
        }

        val query = buildOverpassQuery(centerLat, centerLng, clampedRadiusKm * 1000)

        var lastError: Exception? = null
        for (endpoint in OVERPASS_ENDPOINTS) {
            try {
                val formBody = FormBody.Builder()
                    .add("data", query)
                    .build()
                val request = Request.Builder()
                    .url(endpoint)
                    .post(formBody)
                    .header("User-Agent", "RotaTaxi-Android/1.0 (Luanda Transit)")
                    .build()

                val responseBody = client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        throw IllegalStateException("Overpass HTTP ${response.code}")
                    }
                    response.body?.string() ?: throw IllegalStateException("Resposta vazia do OpenStreetMap")
                }

                val parsed = parseOverpassJson(responseBody, centerLat, centerLng, clampedRadiusKm)
                cacheMutex.withLock {
                    cachedCenterLat = centerLat
                    cachedCenterLng = centerLng
                    cachedMaxRadiusKm = clampedRadiusKm
                    cachedPois = parsed
                    lastFetchEpochMs = System.currentTimeMillis()
                }
                return@withContext Result.success(parsed)
            } catch (e: Exception) {
                Log.w(TAG, "Overpass request failed on $endpoint: ${e.message}")
                lastError = e
            }
        }

        // Fallback to stale cache filtered to requested radius if offline/throttled
        val staleFallback = cacheMutex.withLock {
            if (cachedPois.isNotEmpty()) {
                cachedPois.filter {
                    GeoUtils.isWithinRadiusKm(centerLat, centerLng, it.latitude, it.longitude, clampedRadiusKm)
                }
            } else null
        }
        if (staleFallback != null) {
            return@withContext Result.success(staleFallback)
        }

        Result.failure(lastError ?: IllegalStateException("Não foi possível carregar referências do OpenStreetMap."))
    }

    internal fun parseOverpassJson(
        rawJson: String,
        centerLat: Double,
        centerLng: Double,
        radiusKm: Int
    ): List<MapPoi> {
        val root = JSONObject(rawJson)
        val elements = root.optJSONArray("elements") ?: return emptyList()
        val dedup = LinkedHashMap<String, MapPoi>()

        for (i in 0 until elements.length()) {
            val el = elements.optJSONObject(i) ?: continue
            val tags = el.optJSONObject("tags") ?: continue
            val name = tags.optString("name").trim()
            if (name.isEmpty()) continue

            val lat = when {
                el.has("lat") -> el.optDouble("lat", Double.NaN)
                el.has("center") -> el.optJSONObject("center")?.optDouble("lat", Double.NaN) ?: Double.NaN
                else -> Double.NaN
            }
            val lng = when {
                el.has("lon") -> el.optDouble("lon", Double.NaN)
                el.has("center") -> el.optJSONObject("center")?.optDouble("lon", Double.NaN) ?: Double.NaN
                else -> Double.NaN
            }
            if (lat.isNaN() || lng.isNaN()) continue
            if (!GeoUtils.isWithinRadiusKm(centerLat, centerLng, lat, lng, radiusKm)) continue

            val category = classifyTags(tags) ?: continue
            val id = "${el.optString("type", "node")}_${el.optLong("id", i.toLong())}"
            val subtitle = tags.optString("addr:street").trim()
                .ifEmpty { tags.optString("operator").trim() }
                .ifEmpty { category.labelPt }

            dedup[id] = MapPoi(
                id = id,
                name = name,
                category = category,
                latitude = lat,
                longitude = lng,
                subtitle = subtitle,
                isRotaTaxiRegistered = false
            )
        }

        // Sort nearest first and cap per category so UI stays clean and responsive
        return dedup.values
            .sortedBy { GeoUtils.haversineDistanceKm(centerLat, centerLng, it.latitude, it.longitude) }
            .take(MAX_POIS_RENDERED)
    }

    internal fun classifyTags(tags: JSONObject): PoiCategory? {
        val amenity = tags.optString("amenity")
        val highway = tags.optString("highway")
        val publicTransport = tags.optString("public_transport")
        val shop = tags.optString("shop")
        val office = tags.optString("office")

        return when {
            highway == "bus_stop" || amenity == "taxi" ||
                publicTransport == "platform" || publicTransport == "stop_position" -> PoiCategory.TAXI_STOP
            amenity == "hospital" || amenity == "clinic" || amenity == "doctors" -> PoiCategory.HOSPITAL
            amenity == "school" || amenity == "university" || amenity == "college" -> PoiCategory.SCHOOL
            amenity == "marketplace" || shop == "supermarket" -> PoiCategory.MARKET
            amenity == "bank" || amenity == "atm" -> PoiCategory.BANK
            amenity == "townhall" || amenity == "courthouse" || amenity == "police" ||
                amenity == "embassy" || office == "government" -> PoiCategory.INSTITUTION
            else -> null
        }
    }

    internal fun buildOverpassQuery(lat: Double, lng: Double, radiusMeters: Int): String {
        val r = radiusMeters.coerceIn(1000, 20000)
        return """
            [out:json][timeout:12];
            (
              nwr["highway"="bus_stop"](around:$r,$lat,$lng);
              nwr["amenity"="taxi"](around:$r,$lat,$lng);
              nwr["public_transport"="platform"](around:$r,$lat,$lng);
              nwr["amenity"~"^(hospital|clinic|school|university|college|marketplace|bank|townhall|courthouse|police|embassy)$"](around:$r,$lat,$lng);
              nwr["shop"="supermarket"](around:$r,$lat,$lng);
              nwr["office"="government"](around:$r,$lat,$lng);
            );
            out center 160;
        """.trimIndent()
    }

    companion object {
        private const val TAG = "OsmPoiRepository"
        private const val CACHE_REUSE_DRIFT_KM = 0.8
        private const val CACHE_TTL_MS = 3 * 60 * 1000L
        private const val MAX_POIS_RENDERED = 120

        private val OVERPASS_ENDPOINTS = listOf(
            "https://overpass-api.de/api/interpreter",
            "https://overpass.kumi.systems/api/interpreter"
        )

        private fun defaultClient(): OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(14, TimeUnit.SECONDS)
            .build()
    }
}
