package com.example.util

import java.util.Locale
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

enum class MapRadiusKm(val km: Int, val meters: Int, val leafletZoom: Int) {
    KM_5(5, 5_000, 14),
    KM_10(10, 10_000, 13),
    KM_15(15, 15_000, 12),
    KM_20(20, 20_000, 11);

    companion object {
        val DEFAULT = KM_5
        val MAX = KM_20
    }
}

data class GeoBounds(
    val minLat: Double,
    val maxLat: Double,
    val minLng: Double,
    val maxLng: Double
)

object GeoUtils {
    private const val EARTH_RADIUS_KM = 6371.0

    fun haversineDistanceKm(
        lat1: Double,
        lng1: Double,
        lat2: Double,
        lng2: Double
    ): Double {
        val dLat = Math.toRadians(lat2 - lat1)
        val dLng = Math.toRadians(lng2 - lng1)
        val rLat1 = Math.toRadians(lat1)
        val rLat2 = Math.toRadians(lat2)

        val a = sin(dLat / 2).pow(2) +
            cos(rLat1) * cos(rLat2) * sin(dLng / 2).pow(2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return EARTH_RADIUS_KM * c
    }

    fun haversineDistanceMeters(
        lat1: Double,
        lng1: Double,
        lat2: Double,
        lng2: Double
    ): Double = haversineDistanceKm(lat1, lng1, lat2, lng2) * 1000.0

    fun isWithinRadiusKm(
        centerLat: Double,
        centerLng: Double,
        targetLat: Double,
        targetLng: Double,
        radiusKm: Int
    ): Boolean {
        if (radiusKm <= 0) return false
        return haversineDistanceKm(centerLat, centerLng, targetLat, targetLng) <= radiusKm.toDouble()
    }

    fun boundingBox(
        centerLat: Double,
        centerLng: Double,
        radiusKm: Int
    ): GeoBounds {
        val latDelta = (radiusKm / EARTH_RADIUS_KM) * (180.0 / PI)
        val cosLat = cos(Math.toRadians(centerLat)).coerceAtLeast(0.01)
        val lngDelta = (radiusKm / (EARTH_RADIUS_KM * cosLat)) * (180.0 / PI)
        return GeoBounds(
            minLat = (centerLat - latDelta).coerceIn(-90.0, 90.0),
            maxLat = (centerLat + latDelta).coerceIn(-90.0, 90.0),
            minLng = (centerLng - lngDelta).coerceIn(-180.0, 180.0),
            maxLng = (centerLng + lngDelta).coerceIn(-180.0, 180.0)
        )
    }

    fun formatDistancePt(meters: Double): String {
        return if (meters < 1000.0) {
            "${meters.roundToInt()} m"
        } else {
            String.format(
                Locale.Builder().setLanguage("pt").setRegion("AO").build(),
                "%.1f km",
                meters / 1000.0
            )
        }
    }
}
